package com.maxtra.transportuser.model.loaderwalletlistmodel

import com.google.gson.annotations.SerializedName
 data class LoaderWalletListResponseModel(
    var TotalAmount: Int,
    var `data`: List<LoaderWalletListData>,
    var message: String,
    var status: Int
)

data class LoaderWalletListData(
    var amount: String,
    var credit: String,
    var debit: String,
    var name: String,
    var transaction_date: String,
    var user_id: Int
)