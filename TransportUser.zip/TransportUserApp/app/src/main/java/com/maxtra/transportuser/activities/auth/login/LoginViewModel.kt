package com.maxtra.transportuser.activities.auth.login

import android.content.Context
import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.maxtra.transportuser.data.MainRepository
import com.maxtra.transportuser.model.commonresponse.CommonResponseModel
import com.maxtra.transportuser.model.loginOtpModel.LoginOtpResponseModel
import com.maxtra.transportuser.model.loginResponse.LoginResponseModel
import com.maxtra.transportuser.util.Utils

import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.launch
import java.net.ConnectException
import javax.inject.Inject

@HiltViewModel
class LoginViewModel  @Inject constructor(private val mainRepository: MainRepository, @ApplicationContext val context: Context, private val utils : Utils): ViewModel() {
    val userLoginResponse = MutableLiveData<LoginResponseModel>()
    val progressBarStatus = MutableLiveData<Boolean>()
    val userOtpVerificationResponse = MutableLiveData<LoginOtpResponseModel>()

    fun userLogin(mobile : String,
                  device_id: String,
                  device_type: String,
                  device_name: String,
                  device_token: String) {
        progressBarStatus.value = true
        viewModelScope.launch {
            try {
                val response = mainRepository.userLogin(mobile,device_id,device_type,device_name,device_token)
                if (response.isSuccessful) {
                    progressBarStatus.value = false
//                Log.d("TAG", response.body().toString())
                    userLoginResponse.postValue(response.body())
                }
                else {
                    progressBarStatus.value = false
                    Log.d("TAG", response.body().toString())
                }
            }
            catch (e: Exception) {
                e.printStackTrace()

                progressBarStatus.value = false
                e.printStackTrace()
                if (e is ConnectException) {
                    utils.simpleAlert(
                        context, "Error", "Please check your Internet connection")
                } else {
                    utils.simpleAlert(context, "Some Error Occurred", "Please check your Internet connection")
                }
            }
        }

    }

    fun userOtpVerification(otp : String , mobile : String) {
        progressBarStatus.value = true
        viewModelScope.launch {
            val response = mainRepository.verifyOTPForLogIn(otp, mobile)
            if (response.isSuccessful) {
                progressBarStatus.value = false
//                Log.d("TAG", response.body().toString())
                userOtpVerificationResponse.postValue(response.body())
            }
            else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }

    }
}