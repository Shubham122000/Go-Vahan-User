package com.maxtra.transportuser.model.bookingreviewpassengerget

import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class BookingReviewPassengerModel (

    @SerializedName("status"  ) var status  : Int?            = null,
    @SerializedName("message" ) var message : String?         = null,
    @SerializedName("data"    ) var data    : ArrayList<BookingReviewPassengerData> = arrayListOf()
)
data class BookingReviewPassengerData (
    @SerializedName("pickup_lat"         ) var pickupLat        : String? = null,
    @SerializedName("pickup_long"        ) var pickupLong       : String? = null,
    @SerializedName("dropup_lat"         ) var dropupLat        : String? = null,
    @SerializedName("dropup_long"        ) var dropupLong       : String? = null,
    @SerializedName("task"               ) var task             : String? = null,
    @SerializedName("picup_location"     ) var picupLocation    : String? = null,
    @SerializedName("dropup_location"    ) var dropupLocation   : String? = null,
    @SerializedName("distance"           ) var distance         : String? = null,
    @SerializedName("total_fare"         ) var totalFare        : String? = null,
    @SerializedName("driver_id"          ) var driverId         : Int?    = null,
    @SerializedName("body_type"          ) var bodyType         : Int?    = null,
    @SerializedName("from_trip"          ) var fromTrip         : String? = null,
    @SerializedName("to_trip"            ) var toTrip           : String? = null,
    @SerializedName("vehicle_owner_name" ) var vehicleOwnerName : String? = null,
    @SerializedName("id"                 ) var id               : Int?    = null,
    @SerializedName("vehicle_name"       ) var vehicleName      : String? = null,
    @SerializedName("year_of_model"      ) var yearOfModel      : Int?    = null,
    @SerializedName("vehicle_number"     ) var vehicleNumber    : String? = null,
    @SerializedName("no_of_tyres"        ) var noOfTyres        : Int?    = null,
    @SerializedName("seat"               ) var seat             : String? = null,
    @SerializedName("bodytype"           ) var bodytype         : String? = null,
    @SerializedName("driver_name"        ) var driverName       : String? = null,
    @SerializedName("mobile_number"      ) var mobileNumber     : String? = null,
    @SerializedName("v_id"               ) var vId              : Int?    = null,
    @SerializedName("vehicle_id"         ) var vehicleId        : Int?    = null,
    @SerializedName("booking_date"       ) var bookingDate      : String? = null,
    @SerializedName("booking_time"       ) var bookingTime      : String? = null,
    @SerializedName("available"          ) var available        : String? = null,
    @SerializedName("main_image"         ) var mainImage        : String? = null,
    @SerializedName("owner_name"         ) var ownerName        : String? = null,
    @SerializedName("owner_id"           ) var ownerId          : Int?    = null,
    @SerializedName("rating"             ) var rating           : Int?    = null,
    @SerializedName("amount_pay"             ) var amount_pay           : Int?    = null,

)




/*@SerializedName("vehicle_id"   ) var vehicleId   : Int?    = null,
   @SerializedName("driver_id"    ) var driverId    : Int?    = null,
   @SerializedName("vehicle_name" ) var vehicleName : String? = null,
   @SerializedName("vehicle_no"   ) var vehicleNo   : String? = null,
   @SerializedName("available"    ) var available   : Int?    = null,
   @SerializedName("name"         ) var name        : String? = null,
   @SerializedName("v_id"         ) var vId         : Int?    = null,
   @SerializedName("userid"       ) var userid      : Int?    = null,
   @SerializedName("model"        ) var model       : String? = null,
   @SerializedName("v_type"       ) var vType       : String? = null,
   @SerializedName("seat"         ) var seat        : Int?    = null,
   @SerializedName("v_color"      ) var vColor      : String? = null,
   @SerializedName("wheel"        ) var wheel       : String? = null,
   @SerializedName("from_address" ) var fromAddress : String? = null,
   @SerializedName("to_address"   ) var toAddress   : String? = null,
   @SerializedName("distance"     ) var distance    : String? = null,
   @SerializedName("final_fare"   ) var finalFare   : String? = null,
   @SerializedName("pickup_lat"   ) var pickupLat   : String? = null,
   @SerializedName("pickup_long"  ) var pickupLong  : String? = null,
   @SerializedName("dropup_lat"   ) var dropupLat   : String? = null,
   @SerializedName("dropup_long"  ) var dropupLong  : String? = null,
   @SerializedName("image"        ) var image       : String? = null,
   @SerializedName("booking_date" ) var bookingDate : String? = null,
   @SerializedName("booking_time" ) var bookingTime : String? = null,
   @SerializedName("rating"       ) var rating      : String? = null,
   @SerializedName("owner_name"   ) var ownerName   : String? = null,
   @SerializedName("owner_id"     ) var ownerId     : Int?    = null*/
