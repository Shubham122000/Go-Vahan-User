package com.maxtra.transportuser.activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.LinearLayoutManager
import com.maxtra.transportuser.R
import com.maxtra.transportuser.activities.loadercomplaintboxdetail.LoaderComplaintBoxDetailViewModel
import com.maxtra.transportuser.adapters.CompletedPassengerTripHistoryAdapter
import com.maxtra.transportuser.adapters.PassengerBookingHistoryViewPagerAdapter
import com.maxtra.transportuser.adapters.ReviewsAdapter
import com.maxtra.transportuser.baseClasses.BaseActivity
import com.maxtra.transportuser.databinding.ActivityLoaderComplaintBoxDetailBinding
import com.maxtra.transportuser.databinding.ActivityReviewsBinding
import com.maxtra.transportuser.model.ReviewsData
import com.maxtra.transportuser.model.loaderComplaintlistmodel.LoaderComplaintData
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class ReviewsActivity : BaseActivity() {
    private lateinit var binding : ActivityReviewsBinding
    private val viewModel : LoaderComplaintBoxDetailViewModel by viewModels()
    var reviewsdata : ArrayList<ReviewsData> = ArrayList()
    var driver_id=""
    private var reviewsAdapter : ReviewsAdapter?= null
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_reviews)
       if ( intent!=null){
           driver_id=intent.getStringExtra("driver_id").toString()
       }
        viewModel.progressBarStatus.observe(this){
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }

        binding.ivBack.setOnClickListener(View.OnClickListener {
            finish()
        })
        viewModel.search_loader_driver_review("Bearer " + userPref.user.apiToken,
            driver_id
        )
        viewModel.reviewsresonse.observe(this){
            if (it.status == 1) {
            reviewsdata.clear()
            if (it.data!=null&& it.data.isNotEmpty()){
                reviewsdata.addAll(it.data)
            }
//                reviewsdata.addAll(it.data)
//                binding.rvReviews.layoutManager = LinearLayoutManager(this)
                reviewsAdapter = ReviewsAdapter(reviewsdata)
                binding.rvReviews.adapter =reviewsAdapter
                reviewsAdapter!!.notifyDataSetChanged()



        }else{
            toast(this,it.message)
            }

    }
    }
}