package com.maxtra.transportuser.model.passengerlivetrackingmodel


import com.google.gson.annotations.SerializedName


data class PassengerLiveTrackingResponseModel (

    @SerializedName("status"  ) var status  : Int?            = null,
    @SerializedName("message" ) var message : String?         = null,
    @SerializedName("data"    ) var data    : ArrayList<PassengerLiveTrackingResponseData> = arrayListOf()

)


data class PassengerLiveTrackingResponseData (

    @SerializedName("booking_status"  ) var bookingStatus  : String? = null,
    @SerializedName("fare"            ) var fare           : String? = null,
    @SerializedName("picup_location"  ) var picupLocation  : String? = null,
    @SerializedName("drop_location"   ) var dropLocation   : String? = null,
    @SerializedName("booking_date"    ) var bookingDate    : String? = null,
    @SerializedName("booking_time"    ) var bookingTime    : String? = null,
    @SerializedName("body_type"       ) var bodyType       : String? = null,
    @SerializedName("capacity"        ) var capacity       : String? = null,
    @SerializedName("vehicle_numbers" ) var vehicleNumbers : String? = null,
    @SerializedName("payment_mode"    ) var paymentMode    : String? = null,
    @SerializedName("user_id"         ) var userId         : String? = null,
    @SerializedName("driver_id"       ) var driverId       : Int?    = null,
    @SerializedName("vechicle_id"     ) var vechicleId     : String? = null,
    @SerializedName("vehicle_name"    ) var vehicleName    : String? = null,
    @SerializedName("vehicle_image"   ) var vehicleImage   : String? = null,
    @SerializedName("driver_name"     ) var driverName     : String? = null,
    @SerializedName("mobile"          ) var mobile         : String? = null,
    @SerializedName("driver_image"    ) var driverImage    : String? = null

)