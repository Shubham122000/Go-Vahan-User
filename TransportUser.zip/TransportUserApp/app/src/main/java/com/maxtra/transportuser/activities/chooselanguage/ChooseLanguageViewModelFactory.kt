package com.maxtra.transportuser.activities.chooselanguage

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider


import com.maxtra.transportuser.data.MainRepository
import com.maxtra.transportuser.prefs.UserPref
import javax.inject.Singleton

/*
@Singleton
class ChooseLanguageViewModelFactory(
    private val userPref: UserPref,
    private val repository: MainRepository
): ViewModelProvider.NewInstanceFactory() {

    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return ChooseLanguageViewModel(userPref,repository) as T
    }
}*/
