package com.maxtra.transportuser.util

import android.Manifest.permission.ACCESS_FINE_LOCATION
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat

object Constants {

    val BASE_URL = "http://182.76.237.238/~apitest/rolling_scissors/api/user/"

    const val PERMISSION_REQUEST_CODE = 200
    fun checkPermission(context: Context?): Boolean {
        val location =
            ContextCompat.checkSelfPermission((context as Activity?)!!, ACCESS_FINE_LOCATION)
        return location == PackageManager.PERMISSION_GRANTED
    }

}