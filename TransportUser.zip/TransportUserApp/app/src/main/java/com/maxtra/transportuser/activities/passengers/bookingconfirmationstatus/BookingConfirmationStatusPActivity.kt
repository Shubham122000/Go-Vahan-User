package com.maxtra.transportuser.activities.passengers.bookingconfirmationstatus

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.databinding.DataBindingUtil
import com.maxtra.transportuser.R
import com.maxtra.transportuser.activities.DashboardActivity
import com.maxtra.transportuser.activities.bookingreview.BookingReviewActivity
import com.maxtra.transportuser.activities.bookvehicle.BookAVehicleActivity
import com.maxtra.transportuser.activities.passengers.passengerbookingreview.BookingReviewPActivity
import com.maxtra.transportuser.baseClasses.BaseActivity
import com.maxtra.transportuser.databinding.ActivityBookingConfirmationStatusPactivityBinding
import com.maxtra.transportuser.model.bookingpassengelmodel.BookingPassengerData
import com.maxtra.transportuser.model.bookingreviewpassengerget.BookingReviewPassengerData
import dagger.hilt.android.AndroidEntryPoint


@AndroidEntryPoint
class BookingConfirmationStatusPActivity : BaseActivity() {
    private lateinit var binding : ActivityBookingConfirmationStatusPactivityBinding
    var ppaymentMode:String?=null
    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_booking_confirmation_status_pactivity)

        binding.header.ivBack.setOnClickListener(View.OnClickListener {
            finish()

        })

        binding.header.tvHeaderText.setText("Booking Confirmation & Status")

        binding.btnBack.setOnClickListener(View.OnClickListener {

            val intent = Intent(this, DashboardActivity::class.java)
            startActivity(intent)
            finish()

        })


      //  binding.tvRideCode.text = BookingReviewPActivity.bookingLoaderRideCode


        if (intent!=null) {
            ppaymentMode = intent.getStringExtra("payment_mode")

            try {


                for (i in 0 until BookingReviewPActivity.bookingPassengerOnlineDataList.size) {
                    binding.bookingid.text =
                        "Booking Id: #" + BookingReviewPActivity.bookingPassengerOnlineDataList[i].bookingId
                    binding.tvBookingCreatedate.text =
                        BookingReviewPActivity.bookingPassengerOnlineDataList[i].bookingDate

                    binding.tvVehicleName.text =
                        BookingReviewPActivity.bookingPassengerOnlineDataList[i].vehicleNumbers
                    binding.tvFrom.text =
                        BookingReviewPActivity.bookingPassengerOnlineDataList[i].picupLocation
                    binding.tvTo.text =
                        BookingReviewPActivity.bookingPassengerOnlineDataList[i].dropLocation
                    binding.tvVehicleNumber.text =
                        BookingReviewPActivity.bookingPassengerOnlineDataList[i].vehicleNumbers
                    binding.tvRating.text =
                        BookingReviewPActivity.bookingPassengerOnlineDataList[i].rating
                    binding.tvType.text =
                        BookingReviewPActivity.bookingPassengerOnlineDataList[i].bodyType
                    binding.tvCapacity.text =
                        BookingReviewPActivity.bookingPassengerOnlineDataList[i].capacity.toString()
                    binding.tvDistance.text =
                        BookingReviewPActivity.bookingPassengerOnlineDataList[i].distance
                    //   binding.tvOwnerName.text = BookingReviewPActivity.bookingPassengerOnlineDataList[i].ow
                    binding.tvBookingdate.text =
                        BookingReviewPActivity.bookingPassengerOnlineDataList[i].bookingDate

                    binding.tvAmount.text =
                        BookingReviewPActivity.bookingPassengerOnlineDataList[i].fare
                    binding.tvPaymentmode.text = "Online"
                    binding.tvBookingStatus.text = "Partial Payment Completed"
                    binding.tvRideCode.text =
                    "₹${BookingReviewPActivity.bookingPassengerOnlineDataList[i].ride_code}"

                    // binding.tvPaymentmode.text = BookingReviewPActivity.bookingPassengerOnlineDataList[i].bookingDate

                    /*if(BookingReviewPActivity.bookingPassengerOnlineDataList[i].paymentMode.equals("1"))
                    {binding.tvPaymentmode.setText("Cash")}
                    else  if(BookingReviewPActivity.bookingPassengerOnlineDataList[i].paymentMode.equals("2"))
                    {binding.tvPaymentmode.setText("Online")}*/

//                    if(BookingReviewPActivity.bookingPassengerOnlineDataList[i].bookingStatus.equals("1")){
//                        binding.tvBookingStatus.text = "Pending"
//                    }
//                    else if(BookingReviewPActivity.bookingPassengerOnlineDataList[i].bookingStatus.equals("2")){
//                        binding.tvBookingStatus.text = "Accepted"
//                    }
//                    else if(BookingReviewPActivity.bookingPassengerOnlineDataList[i].bookingStatus.equals("3")){
//                        binding.tvBookingStatus.text = "Cancel"
//                    }
//                    else if(BookingReviewPActivity.bookingPassengerOnlineDataList[i].bookingStatus.equals("4")){
//                        binding.tvBookingStatus.text = "Completed"
//                    }

                    /*if(BookingReviewPActivity.bookingPassengerOnlineDataList[i].available.toString().equals("0")){
                        binding.tvAvailable.text = "Not Available"
                        binding.tvAvailable.visibility = View.VISIBLE
                        binding.ivCheck.visibility = View.GONE
                    }
                    else if(it.data[0].available.toString().equals("1")){
                        binding.tvAvailable.text = "Available"
                        binding.tvAvailable.visibility = View.VISIBLE
                        binding.ivCheck.visibility = View.VISIBLE
                    }*/

                }

                for (i in 0 until BookingReviewPActivity.bookingPassengerOnlineUserList.size) {
                    binding.tvUsreName.text =
                        BookingReviewPActivity.bookingPassengerOnlineUserList[i].name
                    binding.tvUserPhone.text =
                        BookingReviewPActivity.bookingPassengerOnlineUserList[i].mobileNumber
                    binding.tvUsreEmail.text =
                        BookingReviewPActivity.bookingPassengerOnlineUserList[i].email
                }

                for (i in 0 until BookingReviewPActivity.bookingPassengerOnlineDriverList.size) {
                    binding.tvDriverNam.text =
                        BookingReviewPActivity.bookingPassengerOnlineDriverList[i].name
                    binding.tvDrivername.text =
                        BookingReviewPActivity.bookingPassengerOnlineDriverList[i].name
                    binding.tvDriverphone.text =
                        BookingReviewPActivity.bookingPassengerOnlineDriverList[i].mobileNumber
                }


//            }
            }catch (e:Exception){
                e.printStackTrace()
            }
        }
        }
}