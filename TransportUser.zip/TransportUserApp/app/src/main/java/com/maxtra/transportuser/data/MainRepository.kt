package com.maxtra.transportuser.data


import com.maxtra.transportuser.model.AddRatingModel
import com.maxtra.transportuser.model.ReviewsData
import com.maxtra.transportuser.model.ReviewsModelClass
import com.maxtra.transportuser.model.addfavouritelocation.AddFavouriteLocationModel
import com.maxtra.transportuser.model.authorisedFranchisesDisttListModel.AuthorisedFranchisesDisttListResponseModel
import com.maxtra.transportuser.model.authorisedFranchisesPincodeListModel.AuthorisedFranchisesPinCodeListResponseModel
import com.maxtra.transportuser.model.authorisedFranchisesStateListModel.AuthorisedFranchisesStateListResponseModel
import com.maxtra.transportuser.model.authorizedfranchisesmodel.AuthorizedFranchisesResponseModel
import com.maxtra.transportuser.model.bookingloadermodel.BookingLoaderResponseModel
import com.maxtra.transportuser.model.bookingpassengelmodel.BookingPassengerResponseModel
import com.maxtra.transportuser.model.bookingreviewget.BookingReviewModel
import com.maxtra.transportuser.model.bookingreviewpassengerget.BookingReviewPassengerModel
import com.maxtra.transportuser.model.cancelledloadertriphistorymodel.CancelledLoaderTripHistoryResponseModel
import com.maxtra.transportuser.model.cancelledpassengertriphistorymodel.CancelledPassengerTripHistoryResponseModel
import com.maxtra.transportuser.model.completedloadertriphistorymodel.CompletedLoaderTripHistoryResponseModel
import com.maxtra.transportuser.model.completedpassengertriphistorymodel.CompletedPassengerTripHistoryResponseModel
import com.maxtra.transportuser.model.contactusmodel.ContactUsModel
import com.maxtra.transportuser.model.deletefavlocation.DeleteFavLocationModel
import com.maxtra.transportuser.model.getPrivacyPolicy.PrivacyPolicyModel
import com.maxtra.transportuser.model.getRating.GetRatingModel
import com.maxtra.transportuser.model.getfavouritelocation.GetFavouriteLocationModel
import com.maxtra.transportuser.model.getprofile.GetUserProfileModel
import com.maxtra.transportuser.model.homebannermodel.HomeBannerResponseModel
import com.maxtra.transportuser.model.loaderAddRaiseComplaintModel.LoaderAddRaiseComplaintResponseModel
import com.maxtra.transportuser.model.loaderComplaintListDetailModel.LoaderComplaintListDetailResponseModel
import com.maxtra.transportuser.model.loaderComplaintlistmodel.LoaderComplaintListResponseModel
import com.maxtra.transportuser.model.loaderInvoiceDetailModel.LoaderInvoiceDetailResponseModel
import com.maxtra.transportuser.model.loaderInvoiceDownloadModel.LoaderDownloadInvoiceUrlResponseModel
import com.maxtra.transportuser.model.loaderRideCompletedModel.LoaderRideCompletedResponseModel
import com.maxtra.transportuser.model.loaderaddwalletmodel.LoaderAddWalletResponseModel
import com.maxtra.transportuser.model.loadercancelreasonmodel.LoaderCancelReasonListResponseModel
import com.maxtra.transportuser.model.loadercanceltripmodel.LoaderTripCancelResponseModel
import com.maxtra.transportuser.model.loaderinvoicelistmodel.LoaderInvoiceListResponseModel
import com.maxtra.transportuser.model.loaderlivetrackingmodel.LoaderLiveTrackingResponseModel
import com.maxtra.transportuser.model.loaderongoinghistorydetailmodel.LoaderOngoingHistoryDetailResponseModel
import com.maxtra.transportuser.model.loaderpaymentsuccessmodel.LoaderPaymentSuccessResponseModel
import com.maxtra.transportuser.model.loaderrescheduletripmodel.LoaderRescheduleTripResponseModel
import com.maxtra.transportuser.model.loadertripmanagementmodel.LoaderTripManagementDetailResponse
import com.maxtra.transportuser.model.loaderwalletfiltermodel.LoaderWalletFilterResponseModel
import com.maxtra.transportuser.model.loaderwalletlistmodel.LoaderWalletListResponseModel
import com.maxtra.transportuser.model.loginOtpModel.LoginOtpResponseModel
import com.maxtra.transportuser.model.loginResponse.LoginResponseModel
import com.maxtra.transportuser.model.myoffersmodel.MyOffersResponseModel
import com.maxtra.transportuser.model.noOfTyrePModel.GetNoOfTyrePModel
import com.maxtra.transportuser.model.notificationmodel.NotificationResponseModel
import com.maxtra.transportuser.model.ongoingPassengerTripHistoryModel.OngoingPassengerTripHistoryResponseModel
import com.maxtra.transportuser.model.ongoingloadertriphistorymodel.OngoingLoaderTripHistoryResponseModel
import com.maxtra.transportuser.model.passengerAddRaiseComplaintModel.PassengerAddRaiseComplaintResponseModel
import com.maxtra.transportuser.model.passengerComplaintlistdetailmodel.PassengerComplaintListDetailResponseModel
import com.maxtra.transportuser.model.passengerComplaintlistmodel.PassengerComplaintListResponseModel
import com.maxtra.transportuser.model.passengerInvoiceDetailModel.PassengerInvoiceDetailResponseModel
import com.maxtra.transportuser.model.passengerOngoinghistorydetailmodel.PassengerOngoingHistoryDetailResponseModel
import com.maxtra.transportuser.model.passengerRideCompletedModel.PassengerRideCompletedResponseModel
import com.maxtra.transportuser.model.passengeraddratingmodel.PassengerAddRatingResponseModel
import com.maxtra.transportuser.model.passengercancelreasonmodel.PassengerCancelReasonListResponseModel
import com.maxtra.transportuser.model.passengercanceltripmodel.PassengerTripCancelResponseModel
import com.maxtra.transportuser.model.passengerdownloadinvoicemodel.PassengerDownloadInvoiceUrlResponseModel
import com.maxtra.transportuser.model.passengerinvoicelistmodel.PassengerInvoiceListResponseModel
import com.maxtra.transportuser.model.passengerlivetrackingmodel.PassengerLiveTrackingResponseModel
import com.maxtra.transportuser.model.passengerpaymentsuccessmodel.PassengerPaymentSuccessResponseModel
import com.maxtra.transportuser.model.passengertripmanagementmodel.PassengerTripManagementDetailResponse
import com.maxtra.transportuser.model.searchPassengerVehicle.SearchPassengerVehicleResponseModel
import com.maxtra.transportuser.model.searchauthorisedfranchisesmodel.SearchAuthorisedFranchisesResponseModel
import com.maxtra.transportuser.model.searchvehiclemodel.SearchVehicleResponseModel
import com.maxtra.transportuser.model.seatingcapacitymodel.GetSeatingCapacityModel
import com.maxtra.transportuser.model.sendmailmodel.LoaderSendMailResponseModel
import com.maxtra.transportuser.model.settingsmsemailmodel.SettingSmsEmailResponseModel
import com.maxtra.transportuser.model.settingwhatsappmodel.SettingWhatsappResponseModel
import com.maxtra.transportuser.model.transportownerget.TransportOwnerModel
import com.maxtra.transportuser.model.tripmanagementloadermodel.LoaderTripManagementResponseModel
import com.maxtra.transportuser.model.tripmanagementpassengermodel.PassengerTripManagementResponseModel
import com.maxtra.transportuser.model.truckbodytypeget.TruckBodyTypeModel
import com.maxtra.transportuser.model.truckcapacityget.TruckCapacityGetModel
import com.maxtra.transportuser.model.trucknooftyreget.TruckNoOfTyreModel
import com.maxtra.transportuser.model.truckpricefor_get.TruckPriceForModel
import com.maxtra.transportuser.model.trucktypegetmodel.TruckTypeModel
import com.maxtra.transportuser.model.vehicletypemodel.GetVehicleTypeModel
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Response

interface MainRepository {
  /*  suspend fun userRegistration(name : String, email : String, mobile : String, device_id : String,
                                 device_type : String , device_name : String, device_token : String) : Response<OtpModel>
*/
    suspend fun verifyOTPForLogIn(otp : String, mobile : String) : Response<LoginOtpResponseModel>

    suspend fun userLogin(mobile : String,
                          device_id: String,
                          device_type: String,
                          device_name: String,
                          device_token: String) : Response<LoginResponseModel>

   suspend fun getUserProfile(token : String) : Response<GetUserProfileModel>

suspend fun updateUserProfile(token : String, name : RequestBody, email : RequestBody,
                              mobile_number : RequestBody,
                              address : RequestBody, device_token : RequestBody,
                                  device_type : RequestBody, device_id : RequestBody,
                              profile_image : MultipartBody.Part?) : Response<LoginOtpResponseModel>

    suspend fun contactUsApi(token : String) : Response<ContactUsModel>

    suspend fun privacyPolicyApi(token : String) : Response<PrivacyPolicyModel>

    suspend fun termsAndConditions(token : String) : Response<PrivacyPolicyModel>
   suspend fun truckTypeApi(token : String) : Response<TruckTypeModel>
    suspend fun truckCapacityApi(token : String) : Response<TruckCapacityGetModel>
    suspend fun truckBodyTypeApi(token : String) : Response<TruckBodyTypeModel>
    suspend fun truckNoOfTyreApi(token : String) : Response<TruckNoOfTyreModel>
    suspend fun truckPriceForApi(token : String) : Response<TruckPriceForModel>

    suspend fun searchLoaderVehicleApi(token : String,
                                 task : String,
                                 pickup_location : String,
                                 pickup_lat : String,
                                 pickup_long : String,
                                 dropup_location : String,
                                 dropup_lat : String,
                                 dropup_long : String,
                                 truck_type : String,
                                 capacity : String,
                                 body_type : String,
                                 wheel : String,
                               price_for : String,
                               booking_date : String,
                               booking_time : String) : Response<SearchVehicleResponseModel>

    suspend fun searchLoaderDetailApi(token : String ,
                                      id : String,
                                      task : String,
                                      pickup_location : String,
                                      pickup_lat : String,
                                      pickup_long : String,
                                      dropup_location : String,
                                      dropup_lat : String,
                                      dropup_long : String,
                                      booking_date : String,
                                      available : String) : Response<BookingReviewModel>

    suspend fun owner_driverDetailApi(token : String ,
                                      driver_id : String) : Response<TransportOwnerModel>

    suspend fun addRatingApi(token : String ,
                                      driver_id : String,rating : String ,desc : String ) : Response<AddRatingModel>

    suspend fun getRatingApi(token : String,
                             driver_id : String
                        ) : Response<ReviewsModelClass>
    suspend fun my_wallet_payment(header: String,type:String,transaction_id:String,amount: String): Response<LoaderAddWalletResponseModel>

    suspend fun addFavouriteLocationApi(token : String,
                                       pickup_lat : String,
                                       pickup_long : String,
                                       dropup_lat : String,
                                       dropup_long : String
                                       ) : Response<AddFavouriteLocationModel>

    suspend fun getFavouriteLocationApi(token : String) : Response<GetFavouriteLocationModel>

    suspend fun vehicleTypeApi(token : String) : Response<GetVehicleTypeModel>

    suspend fun seatingCapacityApi(token : String) : Response<GetSeatingCapacityModel>

    suspend fun noOfTyrePApi(token : String) : Response<GetNoOfTyrePModel>

    suspend fun deleteFavLocationApi(token : String, id : String) : Response<DeleteFavLocationModel>
   suspend fun search_loader_driver_review(token : String, driver_id : String) : Response<ReviewsModelClass>

    suspend fun searchPassengerVehicleApi(token : String,
                                       pickup_lat : String,
                                       pickup_long : String,
                                       dropup_lat : String,
                                       dropup_long : String,
                                          vehicle_type : String,
                                          seat : String,
                                          tyers : String,
                                       booking_date : String,
                                          pickup_location : String,
                                          dropup_location : String,) : Response<SearchPassengerVehicleResponseModel>

    suspend fun searchPassengerDetailApi(token : String ,
                                         pickup_lat : String,
                                         pickup_long : String,
                                         dropup_lat : String,
                                         dropup_long : String,
                                         vehicle_type : String,
                                         seat : String,
                                         tyers : String,
                                         booking_date : String,
                                         booking_time : String,
                                         vehicle_id : String,
                                         id : String) : Response<BookingReviewPassengerModel>

    suspend fun bookingPassengerApi(token : String ,
                                    pick_up_location : String,
                                    pick_up_lat : String,
                                    pick_up_long : String,
                                    drop_location : String,
                                    drop_lat : String,
                                    drop_long : String,
                                    vechicle_id : String,
                                    fare : String,
                                    payment_mode : String,
                                    booking_date : String,
                                    booking_time : String,
                                    driver_id : String) : Response<BookingPassengerResponseModel>

    suspend fun bookingLoaderApi(
        token: String,
        pick_up_location: String,
        pick_up_lat: String,
        pick_up_long: String,
        drop_location: String,
        drop_lat: String,
        drop_long: String,
        vechicle_id: String,
        fare: String,
        payment_mode: String,
        booking_date: String,
        booking_time: String,
        driver_id: String,

        body_type: String,
        capacity: String,
        distance: String,
        vehicle_numbers: String) : Response<BookingLoaderResponseModel>

    suspend fun getNotificationListApi(token : String) : Response<NotificationResponseModel>

    suspend fun getLoaderTripManagementApi(token : String) : Response<LoaderTripManagementResponseModel>
    suspend fun getPassengerTripManagementApi(token : String) : Response<PassengerTripManagementResponseModel>

    suspend fun loaderTripManagementDetailApi(token : String ,
                                              booking_id : String) : Response<LoaderTripManagementDetailResponse>

    suspend fun getLoaderCancelReasonListApi(token : String) : Response<LoaderCancelReasonListResponseModel>

    suspend fun loaderTripCancelApi(token : String ,
                                              booking_id : String, reasons_id : String,message : String  ) : Response<LoaderTripCancelResponseModel>

  suspend fun loaderRescheduleTripApi(token : String ,
                                              booking_id : String, booking_date : String,booking_time : String  ) : Response<LoaderRescheduleTripResponseModel>

  suspend fun loaderRideCompletedApi(token : String ,
                                              booking_id : String ) : Response<LoaderRideCompletedResponseModel>

  suspend fun loaderOngoingBookingTripHistoryApi(token : String ) : Response<OngoingLoaderTripHistoryResponseModel>

  suspend fun loaderCompletedBookingTripHistoryApi(token : String ) : Response<CompletedLoaderTripHistoryResponseModel>

  suspend fun loaderOngoingHistoryDetailApi(token : String, booking_id : String ) : Response<LoaderOngoingHistoryDetailResponseModel>

  suspend fun loaderInvoiceListApi(token : String ) : Response<LoaderInvoiceListResponseModel>

    suspend fun loaderInvoiceDetailApi(token : String, invoice_numbers : String ) : Response<LoaderInvoiceDetailResponseModel>

    suspend fun loaderPaymentSuccessApi(token : String ,
                                        pick_up_location : String,
                                        pick_up_lat : String,
                                        pick_up_long : String,
                                        drop_location : String,
                                        drop_lat : String,
                                        drop_long : String,
                                        vechicle_id : String,
                                        fare : String,
                                        payment_mode : String,
                                        booking_date : String,
                                        driver_id : String,
                                        dis : String,
                                        body_type : String,
                                        capacity : String,
                                        distance : String,
                                        vehicle_numbers : String,
                                        transaction_id : String,
                                        payment_status : String,
                                        currency : String) : Response<LoaderPaymentSuccessResponseModel>

    suspend fun loaderWalletAddMoneyApi(token : String ,
                                        amount : String) : Response<LoaderAddWalletResponseModel>
    suspend fun loaderWalletListApi(token : String ) : Response<LoaderWalletListResponseModel>
    suspend fun my_wallet_list_download(token : String ) : Response<LoaderWalletListResponseModel>

    suspend fun loaderWalletFilterApi(token : String , date : String ,transaction_type:String) : Response<LoaderWalletFilterResponseModel>

    suspend fun loaderAddRaiseComplaintApi(token : String , booking_id : String , com_message : String ) : Response<LoaderAddRaiseComplaintResponseModel>
    suspend fun loaderComplaintListApi(token : String ) : Response<LoaderComplaintListResponseModel>
    suspend fun loaderComplaintListDetailApi(token : String , booking_id : String ) : Response<LoaderComplaintListDetailResponseModel>

    suspend fun loaderLiveTrackingApi(token : String , booking_id : String ) : Response<LoaderLiveTrackingResponseModel>

    suspend fun passengerPaymentSuccessApi(token : String ,
                                        pick_up_location : String,
                                        pick_up_lat : String,
                                        pick_up_long : String,
                                        drop_location : String,
                                        drop_lat : String,
                                        drop_long : String,
                                        vechicle_id : String,
                                        fare : String,
                                        payment_mode : String,
                                        booking_date : String,
                                        driver_id : String,
                                        dis : String,
                                        body_type : String,
                                        capacity : String,
                                        distance : String,
                                        vehicle_numbers : String,
                                        transaction_id : String,
                                        payment_status : String,
                                        currency : String) : Response<PassengerPaymentSuccessResponseModel>





    suspend fun passengerTripManagementDetailApi(token : String ,
                                              booking_id : String) : Response<PassengerTripManagementDetailResponse>

    suspend fun getPassengerCancelReasonListApi(token : String) : Response<PassengerCancelReasonListResponseModel>

    suspend fun passengerTripCancelApi(token : String ,
                                    booking_id : String, reasons_id : String,message : String  ) : Response<PassengerTripCancelResponseModel>

    suspend fun getDashboardBannertApi(token : String  ) : Response<HomeBannerResponseModel>

    suspend fun passengerRideCompletedApi(token : String ,
                                       booking_id : String ) : Response<PassengerRideCompletedResponseModel>

    suspend fun passengerAddRatingApi(token : String ,
                             driver_id : String,rating : String ,desc : String, user_id : String ) : Response<PassengerAddRatingResponseModel>

    suspend fun getAuthorizedFranchisesApi(token : String) : Response<AuthorizedFranchisesResponseModel>

    suspend fun passengerInvoiceListApi(token : String ) : Response<PassengerInvoiceListResponseModel>

    suspend fun passengerOngoingBookingTripHistoryApi(token : String ) : Response<OngoingPassengerTripHistoryResponseModel>

    suspend fun passengerCompletedBookingTripHistoryApi(token : String ) : Response<CompletedPassengerTripHistoryResponseModel>

    suspend fun passengerOngoingHistoryDetailApi(token : String, booking_id : String ) : Response<PassengerOngoingHistoryDetailResponseModel>

    suspend fun passengerInvoiceDetailApi(token : String, invoice_numbers : String ) : Response<PassengerInvoiceDetailResponseModel>

    suspend fun passengerLiveTrackingApi(token : String , booking_id : String ) : Response<PassengerLiveTrackingResponseModel>
    suspend fun passengerAddRaiseComplaintApi(token : String , booking_id : String , com_message : String ) : Response<PassengerAddRaiseComplaintResponseModel>

    suspend fun passengerComplaintListApi(token : String ) : Response<PassengerComplaintListResponseModel>
    suspend fun passengerComplaintListDetailApi(token : String , booking_id : String ) : Response<PassengerComplaintListDetailResponseModel>
    suspend fun getMyOffersApi(token : String ) : Response<MyOffersResponseModel>
    suspend fun searchAuthorizedFranchisesApi(token : String, state_id : String, district_id : String, pin_code : String ) : Response<SearchAuthorisedFranchisesResponseModel>
    suspend fun sendMailLoaderInvoiceApi(token : String, booking_id : String ) : Response<LoaderSendMailResponseModel>
    suspend fun sendMailPassengerInvoiceApi(token : String, booking_id : String) : Response<LoaderSendMailResponseModel>
    suspend fun loaderCancelledBookingTripHistoryApi(token : String ) : Response<CancelledLoaderTripHistoryResponseModel>
    suspend fun passengerCancelledBookingTripHistoryApi(token : String ) : Response<CancelledPassengerTripHistoryResponseModel>
    suspend fun passengerDownloadInvoiceUrlApi(token : String , booking_id : String  ) : Response<PassengerDownloadInvoiceUrlResponseModel>
    suspend fun loaderDownloadInvoiceUrlApi(token : String , booking_id : String  ) : Response<LoaderDownloadInvoiceUrlResponseModel>
    suspend fun getAuthorisedFranchisesStateListApi(token : String) : Response<AuthorisedFranchisesStateListResponseModel>
    suspend fun getAuthorisedFranchisesDisttListApi(token : String , state_id : String  ) : Response<AuthorisedFranchisesDisttListResponseModel>
    suspend fun getAuthorisedFranchisesPincodeListApi(token : String , city_id : String  ) : Response<AuthorisedFranchisesPinCodeListResponseModel>









    suspend fun settingsWhatsappUpdatesApi(token : String , state_id : String  ) : Response<SettingWhatsappResponseModel>
    suspend fun settingsSmsEmailUpdatesApi(token : String , state_id : String  ) : Response<SettingSmsEmailResponseModel>









}


