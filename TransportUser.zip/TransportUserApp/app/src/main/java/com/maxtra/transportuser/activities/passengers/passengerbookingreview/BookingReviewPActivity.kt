package com.maxtra.transportuser.activities.passengers.passengerbookingreview

import android.annotation.SuppressLint
import android.app.Activity
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.ContentValues
import android.content.ContentValues.TAG
import android.content.Intent
import android.icu.text.SimpleDateFormat
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.Toast
import androidx.activity.viewModels
import androidx.annotation.RequiresApi
import androidx.databinding.DataBindingUtil
import com.bumptech.glide.Glide
import com.maxtra.transportuser.R
import com.maxtra.transportuser.activities.bookingsuccessp.BookingSuccessPActivity
import com.maxtra.transportuser.activities.passengers.paymentmethods.PaymentMethodsPActivity
import com.maxtra.transportuser.activities.transportowner.TransportOwnerActivity
import com.maxtra.transportuser.baseClasses.BaseActivity
import com.maxtra.transportuser.databinding.ActivityBookingReviewPactivityBinding
import com.maxtra.transportuser.model.bookingpassengelmodel.BookingPassengerData
import com.maxtra.transportuser.model.bookingpassengelmodel.BookingPassengerDriver
import com.maxtra.transportuser.model.bookingpassengelmodel.BookingPassengerUser
import com.maxtra.transportuser.model.passengerpaymentsuccessmodel.PassengerPaymentSuccessData
import com.maxtra.transportuser.model.passengerpaymentsuccessmodel.PassengerPaymentSuccessDriver
import com.maxtra.transportuser.model.passengerpaymentsuccessmodel.PassengerPaymentSuccessUser
import com.maxtra.transportuser.model.searchPassengerVehicle.SearchPassengerData
import com.maxtra.transportuser.util.toast
import com.razorpay.Checkout
import com.razorpay.PaymentData
import com.razorpay.PaymentResultWithDataListener
import dagger.hilt.android.AndroidEntryPoint
import org.json.JSONObject
import java.text.ParseException
import java.util.*

@AndroidEntryPoint
class BookingReviewPActivity : BaseActivity(), PaymentResultWithDataListener {
    private lateinit var binding : ActivityBookingReviewPactivityBinding
    private var selectedPassVehicleData : SearchPassengerData?= null
    private val viewModel : BookingReviewPViewModel by viewModels()

    private var searchPassengerData : SearchPassengerData ?= null


    lateinit var getSelectedPaymentMode : String
    var selectedDateFormat2 = ""

    val mcurrentTime = Calendar.getInstance()
    val hour = mcurrentTime[Calendar.HOUR_OF_DAY]
    val minute = mcurrentTime[Calendar.MINUTE]
    val zone = mcurrentTime[Calendar.AM_PM]

    var date = ""
    var time = ""
    var pretime = ""
    var h_vehicle_type = ""
    var amount:Int=0

    var finalamountInt=0

    var selectedItem = ""

    companion object{
        /*Todo:- Cash*/
        //var passengerData: BookingPassengerData? = null
        var bookingPassengerDataList:ArrayList<BookingPassengerData> = ArrayList()
        var bookingPassengerUserList:ArrayList<BookingPassengerUser> = ArrayList()
        var bookingPassengerDriverList:ArrayList<BookingPassengerDriver> = ArrayList()
        /*Todo:- Online*/
        var bookingPassengerOnlineDataList:ArrayList<PassengerPaymentSuccessData> = ArrayList()
        var bookingPassengerOnlineUserList:ArrayList<PassengerPaymentSuccessUser> = ArrayList()
        var bookingPassengerOnlineDriverList:ArrayList<PassengerPaymentSuccessDriver> = ArrayList()

    }

    var bpPaymentMode:Boolean?=null

    @SuppressLint("SetTextI18n")
    @RequiresApi(Build.VERSION_CODES.N)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_booking_review_pactivity)

        binding.header.ivBack.setOnClickListener(View.OnClickListener {
            finish()
        })
        binding.header.tvHeaderText.setText("Booking Review")
        binding.llNext.setOnClickListener(View.OnClickListener {
            val intent = Intent(this, PaymentMethodsPActivity::class.java)
            startActivity(intent)
        })

        binding.tvTypechange.setOnClickListener(View.OnClickListener {
            finish()
        })


        h_vehicle_type = intent.getStringExtra("vehicle_type")!!


        //  getSelectedPaymentMode = intent.getStringExtra("choosenPaymentMode").toString()

        val data = intent.extras
        selectedPassVehicleData = data?.getParcelable("vehicleDetails")

        viewModel.progressBarStatus.observe(this) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }

        viewModel.bookingReviewPassengerResponse.observe(this) {
            if (it.status == 1) {
                 toast(it.message!!)
                binding.tvVehicleName.text = it.data[0].vehicleName
                binding.wheelerType.text =  it.data[0].noOfTyres.toString()
                binding.vehicleNumber.text = it.data[0].vehicleNumber
                binding.tvCapacity.text = it.data[0].seat.toString()
                binding.tvDriverName.text = it.data[0].driverName
                binding.tvFrom.text = it.data[0].picupLocation
                binding.tvTo.text = it.data[0].dropupLocation
                binding.tvDistance.text = it.data[0].distance
                binding.tvBookingdate.text = it.data[0].bookingDate
                binding.tvOwner.text = it.data[0].ownerName
                binding.tvType.text = it.data[0].bodytype
                binding.tvAmount.text = "₹" + it.data[0].totalFare
                binding.payableAmount.text = "₹" + it.data[0]?.amount_pay.toString()
                Glide.with(this).load(selectedPassVehicleData?.mainImage).into(binding.ivVehicleImage)

                userPref.setDriverId(it.data[0].driverId.toString())
                pretime = it.data[0].bookingTime.toString()
                try {
//                    val sdf = SimpleDateFormat("H:mm")
////                    val dateObj = sdf.parse(it.data[0].bookingTime)
//                    System.out.println(dateObj)
//                    println(SimpleDateFormat("K:mm a").format(dateObj))
//                    binding.tvBookingtime.text = SimpleDateFormat("K:mm a").format(dateObj)
                } catch (e: ParseException) {
                    e.printStackTrace()
                }
                if(it.data[0].available.toString().equals("0")){
                    binding.tvAvailable.text = "Not Available"
                    binding.tvAvailable.visibility = View.VISIBLE
                    binding.ivCheck.visibility = View.GONE
                }
                else if(it.data[0].available.toString().equals("1")){
                    binding.tvAvailable.text = "Available"
                    binding.tvAvailable.visibility = View.VISIBLE
                    binding.ivCheck.visibility = View.VISIBLE
                }
            } else {
                toast(it.message!!)
            }
        }

        viewModel.bookingPassengerResponseModel.observe(this) {
            if (it.status == 1) {
                toast(it.message!!)
                bookingPassengerDataList.add(it.bookingPassengerData!!)
                bookingPassengerUserList.add(it.bookingPassengerUser!!)
                bookingPassengerDriverList.add(it.bookingPassengerdriver!!)
                bpPaymentMode = false
                startActivity(Intent(this, BookingSuccessPActivity :: class.java)
                .putExtra("modelDataList", bookingPassengerDataList)
                .putExtra("modelUserList", bookingPassengerUserList)
                .putExtra("modelDriverList", bookingPassengerDriverList)
                    .putExtra("cash","CASH"))
             // toast(it.bookingPassengerData[0].bookingId!!)
              finish()
            } else {
                toast(it.message!!)
            }
        }

        viewModel.passengerPaymentSuccessResponseModel.observe(this) {
            if (it.status == 1) {
                // toast("booking Successful")
                /*binding.tvVehicleName.text = it.data?.vechicleId
                binding.wheelerType.text =  it.data?.noOfTyres.toString()
                binding.tvRating.text =  it.data?.rating.toString()
                binding.vehicleNumber.text = it.data?.vehicleName
                binding.tvCapacity.text = it.data?.capacity
                binding.tvDistance.text = it.data?.distance.toString()
                binding.tvFrom.text = it.data?.picupLocation
                binding.tvTo.text = it.data?.dropupLocation
                binding.tvDrivername.text = it.data?.driverName
                binding.tvBookingdate.text = it.data?.bookingDate
                binding.tvBookingtime.text = it.data?.bookingTime
                binding.tvOwnerName.text = it.data?.ownerName
                binding.tvAmount.text = "₹" + it.data?.totalFare
                payAmount=it.data?.totalFare.toString()
                Glide.with(this).load(selectedVehicleData?.mainImage).into(binding.ivVehicleImage)
                userPref.setDriverId(it.data?.driverId.toString())
                pretime = it.data?.bookingTime.toString()*/


                finish()
                if (it.status == 1) {
                    toast(it.message!!)
                    selectedDateFormat2 = selectedPassVehicleData?.bookingDate!!
//                    time = selectedPassVehicleData?.bookingTime!!
                    bookingPassengerOnlineDataList.add(it.data!!)
                    bookingPassengerOnlineUserList.add(it.user!!)
                    bookingPassengerOnlineDriverList.add(it.driver!!)
                    bpPaymentMode = true
                    startActivity(Intent(this, BookingSuccessPActivity :: class.java)
                        .putExtra("modelDataList", bookingPassengerDataList)
                    .putExtra("modelUserList", bookingPassengerUserList)
                        .putExtra("modelDriverList", bookingPassengerDriverList)
                        .putExtra("online","ONLINE"))
                    // toast(it.bookingPassengerData[0].bookingId!!)
                    finish()
                } else {
                    toast(it.message!!)
                }

            } else {
                toast(it.message!!)
            }
        }


        viewModel.searchPassengerDetailApi(
            "Bearer " + userPref.user.apiToken,
            selectedPassVehicleData?.pickupLat!!,
            selectedPassVehicleData?.pickupLong!!,
            selectedPassVehicleData?.dropupLat!!,
            selectedPassVehicleData?.dropupLong!!,
            h_vehicle_type,
            selectedPassVehicleData?.seat!!.toString(),
            selectedPassVehicleData?.noTyres!!.toString(),
            selectedPassVehicleData?.bookingDate!!,
            "",
            selectedPassVehicleData?.vehicleId.toString(),
            selectedPassVehicleData?.id.toString()


        )

        Log.d("TAG__",h_vehicle_type+"__vehicleId__"+ selectedPassVehicleData?.vehicleId.toString())

        binding.tvOwner.setOnClickListener(View.OnClickListener {
            val intent = Intent(this, TransportOwnerActivity::class.java)
            intent.putExtra("putdriveridd", selectedPassVehicleData?.driverId.toString())
            startActivity(intent)
        })

//        binding.spinnerPaymentMode.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
//            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
//                selectedItem = parent.getItemAtPosition(position).toString()
//                Log.d("PositionSelected",selectedItem)
//                if (selectedItem == "Select payment Mode") {
//                    toast("Please select payment mode.")
//                }
//                else if (selectedItem == "Cash") {
//                    toast("Cash")
//                }
//                else if (selectedItem == "Online") {
//
//                    toast("Online")
//                }
//            }
//
//            override fun onNothingSelected(parent: AdapterView<*>?) {}
//        }

        binding.llChangeDateTime.setOnClickListener(View.OnClickListener {
            clickDataPicker()
        })
        binding.btnConfirmbook.setOnClickListener(View.OnClickListener {

//            if (selectedItem == "Select payment Mode") {
//                toast("Please select payment mode.")
//            }
//            else if (selectedItem == "Online"){
//                bpPaymentMode = true
                startPassPayment()


                /*Log.d(TAG, "onPaymentSuccessP: "+userPref.user.apiToken+searchPassengerData?.picupLocation!!+
                        searchPassengerData?.pickupLat!!+searchPassengerData?.pickupLong!!+searchPassengerData?.dropupLocation!!+
                        searchPassengerData?.dropupLat!!+searchPassengerData?.dropupLong!!+1+searchPassengerData?.totalFare.toString()+
                        binding.spinnerPaymentMode.selectedItem.toString()+selectedDateFormat2+time+
                        searchPassengerData?.driverId.toString()+"dis"+searchPassengerData?.bodytype.toString()+
                        searchPassengerData?.seat.toString()+searchPassengerData?.distance.toString()+
                        searchPassengerData?.vehicleNumber.toString())*/

//            }
//            else if (selectedItem=="Cash") {
//                viewModel.bookingPassengerApi(
//                    "Bearer " + userPref.user.apiToken,
//                    selectedPassVehicleData?.picupLocation!!,
//                    selectedPassVehicleData?.pickupLat!!,
//                    selectedPassVehicleData?.pickupLong!!,
//                    selectedPassVehicleData?.dropupLocation!!,
//                    selectedPassVehicleData?.dropupLat!!,
//                    selectedPassVehicleData?.dropupLong!!,
//                    "1",
//                    selectedPassVehicleData?.totalFare.toString(),
//                    binding.spinnerPaymentMode.selectedItem.toString(),
//                    selectedDateFormat2,
//                    time,
//                    selectedPassVehicleData?.driverId.toString()
//                )
//
//            }
        })

        /*Log.d(
            TAG, "onPassPaymentSuccess: "+ "signature"+searchPassengerData?.picupLocation!!+
                    "picupLocation"+ searchPassengerData?.picupLocation!!+
                    "pickupLat"+ searchPassengerData?.pickupLat!!+
                    "dropupLocation"+ searchPassengerData?.dropupLocation!!+
                    "dropupLat"+ searchPassengerData?.dropupLat!!+
                    "dropupLong"+searchPassengerData?.dropupLong!!+
                    "totalFare"+ searchPassengerData?.totalFare.toString()+
                    "selectedItem"+ binding.spinnerPaymentMode.selectedItem.toString()+
                    "selectedDateFormat2"+ selectedDateFormat2+
                    "time"+ time +
                    "driverId"+searchPassengerData?.driverId.toString()+
                    "bodytype"+ searchPassengerData?.bodytype.toString()+
                    "distance"+ searchPassengerData?.distance.toString()+
                    "vehicleNumber"+ searchPassengerData?.vehicleNo.toString()
        )*/

    }

    private fun startPassPayment() {
        amount = (binding.payableAmount.text.toString().replace("₹", "").toFloat() * 100).toInt()
         finalamountInt = amount




        val activity: Activity = this
        val co = Checkout()
        co.setKeyID("rzp_test_ERu25JeZGdnYjs")

        try {
            var options = JSONObject()
            options.put("name",userPref.user.name)
            options.put("description","Demoing Charges")
            //You can omit the image option to fetch the image from dashboard
            options.put("image","https://s3.amazonaws.com/rzp-mobile/images/rzp.png")
            options.put("theme.color", "");
            options.put("currency","INR")
            options.put("amount",finalamountInt)
            options.put("send_sms_hash",true);
            val prefill = JSONObject()
            prefill.put("email",userPref.user.email)
            prefill.put("contact",userPref.user.mobileNumber)
            options.put("prefill",prefill)
            co.open(this@BookingReviewPActivity,options)

        }
        catch (e: Exception){
            Toast.makeText(activity,"Error in payment: "+ e.message, Toast.LENGTH_LONG).show()
            e.printStackTrace()
        }
    }

    @SuppressLint("SimpleDateFormat")
    @RequiresApi(Build.VERSION_CODES.N)
    fun clickDataPicker() {
        val cal = Calendar.getInstance()
        val simpleDateFormat = SimpleDateFormat("dd-MM-yyyy")
        val simpleDateFormat2 = SimpleDateFormat("yyyy-MM-dd")
        cal.timeZone = TimeZone.getTimeZone("UTC")

        val datePickerDialog = DatePickerDialog(
            this, R.style.DatePickerTheme,{ view, year, monthOfYear, dayOfMonth ->
                cal.set(year, monthOfYear, dayOfMonth)
                binding.tvBookingdate.text = simpleDateFormat.format(cal.time)
                selectedDateFormat2 = simpleDateFormat2.format(cal.time)
//                clickTimePicker()
            },
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH),
            cal.get(Calendar.DAY_OF_MONTH)
        )
        datePickerDialog.datePicker.minDate = System.currentTimeMillis() - 1000
        datePickerDialog.show()
    }

//    @SuppressLint("SetTextI18n")
//    @RequiresApi(Build.VERSION_CODES.N)
//    fun clickTimePicker() {
//        val mTimePicker = TimePickerDialog(
//            this, { timePicker, selectedHour, selectedMinute ->
//                /*val AM_PM: String = if (selectedHour < 12) {
//                    "AM"
//                } else {
//                    "PM"
//                }*/
//                time = "$selectedHour:$selectedMinute "
//                // bottomSheet.findViewById<Button>(R.id.tvTime).text = time
//            },
//            hour,
//            minute + zone,
//            false
//        ) //Yes 24 hour time
//        mTimePicker.setTitle("Select Time")
//        mTimePicker.show()
//    }

    override fun onPaymentSuccess(p0: String?, p1: PaymentData?) {
        try {
            viewModel.passengerPaymentSuccessApi("Bearer " + userPref.user.apiToken,
                selectedPassVehicleData?.picupLocation!!,
                selectedPassVehicleData?.pickupLat!!,
                selectedPassVehicleData?.pickupLong!!,
                selectedPassVehicleData?.dropupLocation!!,
                selectedPassVehicleData?.dropupLat!!,
                selectedPassVehicleData?.dropupLong!!,
                selectedPassVehicleData?.vehicleId!!.toString(),
                selectedPassVehicleData?.totalFare.toString(),
            "2",
                binding.tvBookingdate.text.toString(),
                selectedPassVehicleData?.driverId.toString(),
            "dis",
                selectedPassVehicleData?.bodytype.toString() ,
                selectedPassVehicleData?.seat.toString() ,
                selectedPassVehicleData?.distance.toString() ,
                selectedPassVehicleData?.vehicleNo.toString() ,
            p1?.paymentId.toString(),
            "1",
            "INR"
        )

            toast(p1?.paymentId.toString())



        }catch (e: Exception){
            Toast.makeText(this,"Error in payment: "+ e.message,Toast.LENGTH_LONG).show()
            e.printStackTrace()
        }
    }


//    override fun onPaymentSuccess(p1: String?) {
//        viewModel.passengerPaymentSuccessApi("Bearer " + userPref.user.apiToken,
//            searchPassengerData?.picupLocation!!,
//            searchPassengerData?.pickupLat!!,
//            searchPassengerData?.pickupLong!!,
//            searchPassengerData?.dropupLocation!!,
//            searchPassengerData?.dropupLat!!,
//            searchPassengerData?.dropupLong!!,
//            "1",
//            searchPassengerData?.totalFare.toString(),
//            binding.spinnerPaymentMode.selectedItem.toString(),
//            selectedDateFormat2,
//            time,
//            searchPassengerData?.driverId.toString(),
//            "dis",
//            searchPassengerData?.bodytype.toString() ,
//            searchPassengerData?.seat.toString() ,
//            searchPassengerData?.distance.toString() ,
//            searchPassengerData?.vehicleNumber.toString() ,
//            "transaction id",
//            "1" ,
//            "INR"
//        )
//    }

    override fun onPaymentError(p0: Int, p1: String?, p2: PaymentData?) {

        toast("Error")
    }


}