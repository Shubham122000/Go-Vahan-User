package com.maxtra.transportuser.activities.invoicesummarypassenger

import android.R.attr.button
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.databinding.DataBindingUtil
import com.maxtra.transportuser.R
import com.maxtra.transportuser.baseClasses.BaseActivity
import com.maxtra.transportuser.databinding.ActivityPassengerInvoiceSummaryBinding
import com.maxtra.transportuser.model.passengerinvoicelistmodel.PassengerInvoiceData
import com.maxtra.transportuser.util.toast
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class PassengerInvoiceSummaryActivity : BaseActivity() {


    private lateinit var binding: ActivityPassengerInvoiceSummaryBinding
    private var selectedInvoiceListData: String? = null
    private var selectedPassengerListData: PassengerInvoiceData? = null
    private var selectedPassengerInvoiceBookingId: String? = null
    private val viewModel: PassengerInvoiceSummaryDetailsViewModel by viewModels()
    var url :String =""
    var downlloadpdf :String = ""
    var newurl :String = ""

    var manager: DownloadManager? = null



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_passenger_invoice_summary)

        binding.header.ivBack.setOnClickListener(View.OnClickListener {
            finish()
        })
        emailresponse()
        binding.header.tvHeaderText.setText("Invoice Summary")



        val data = intent.extras

        selectedInvoiceListData = intent.getStringExtra("loaderInvoiceDetails").toString()
        selectedPassengerInvoiceBookingId = intent.getStringExtra("passengerInvoiceBookingId").toString()

        viewModel.progressBarStatus.observe(this) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }
        viewModel.passengerDownloadInvoiceResponseModel.observe(this) {
            if (it.status == 1) {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(it.url)))


//                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(it.url)))
                toast("Invoice Downloaded successfully!")
            } else {
                toast(it.message!!)
            }
        }

        viewModel.passengerInvoiceSummaryDetailResponse.observe(this) {
            if (it.status == 1) {
                // toast("booking Successful")
                toast(it.message!!)

                binding.tvInvoiceNumber.text = it.data[0].invoiceNumber
                binding.tvPaymentDate.text = it.data[0].bookingDate
                binding.tvInvoiceDate.text = it.data[0].createdAt
                binding.tvInvoiceTime.text = it.data[0].createdAt

                binding.tvUsername.text = it.userDetails?.name
                binding.tvUserphone.text = it.userDetails?.mobileNumber
                binding.tvUseremail.text = it.userDetails?.email

                binding.tvVehicleType.text = it.data[0].bookingTime
                binding.tvBodyType.text = it.data[0].bodyType
                binding.tvVehicleNumber.text = it.data[0].vehicleNumber
                binding.tvTotalLoads.text = it.data[0].bookingTime
                for (i in 0 until it.ownerDetails.size ){
                    binding.tvPartyOwnerName.text = it.ownerDetails.get(i).name
                    binding.tvPartyOwnderNumber.text = it.ownerDetails?.get(i).mobile

                }
                binding.tvDriverName.text = it.data[0].bookingTime
                binding.tvDriverNumber.text = it.data[0].bookingTime

                binding.tvDepartureplace.text = it.data[0].picupLocation
                binding.tvArrivalplace.text = it.data[0].dropLocation
                binding.tvBookingDate.text = it.data[0].bookingDate
                binding.tvCompleteDate.text = it.data[0].bookingDate
                binding.tvCharges.text = it.data[0].bookingDate
                binding.tvGst.text = it.data[0].bookingDate
                binding.tvCgst.text = it.data[0].bookingTime

                binding.tvTotalamount.text = it.data[0].fare


                if(it.data[0].paymentMode.equals("1"))
                {binding.tvPaymentMode.setText("Cash")}
                else  if(it.data[0].paymentMode.equals("2"))
                {binding.tvPaymentMode.setText("Online")}



            } else {
                toast(it.message!!)
            }
        }




        viewModel.passengerInvoiceDetailApi(
            "Bearer " + userPref.user.apiToken,
            selectedInvoiceListData.toString()
        )



        binding.btnEmail.setOnClickListener {
            viewModel.sendMailPassengerInvoiceApi("Bearer " + userPref.user.apiToken, selectedPassengerInvoiceBookingId.toString())
        }




        binding.btnDownload.setOnClickListener{

            viewModel.passengerDownloadInvoiceUrlApi("Bearer " + userPref.user.apiToken, selectedPassengerInvoiceBookingId.toString())
        }



    }
    fun emailresponse(){

        viewModel.passengerSendMailResponseModel.observe(this) {
            if (it.status == 1) {
                toast("Email Sent P successfully!")

            } else {
                toast(it.message!!)
            }
        }

    }


}