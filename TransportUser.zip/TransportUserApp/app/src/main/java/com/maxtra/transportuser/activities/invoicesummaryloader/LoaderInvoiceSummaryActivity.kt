package com.maxtra.transportuser.activities.invoicesummaryloader

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.databinding.DataBindingUtil
import com.maxtra.transportuser.R
import com.maxtra.transportuser.baseClasses.BaseActivity
import com.maxtra.transportuser.databinding.ActivityInvoiceSummaryBinding
import com.maxtra.transportuser.util.toast
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class LoaderInvoiceSummaryActivity : BaseActivity() {
    private lateinit var binding: ActivityInvoiceSummaryBinding
    private var selectedInvoiceListData: String? = null
    private var selectedInvoiceLoaderBookingId: String? = null
    private val viewModel: InvoiceSummaryDetailsViewModel by viewModels()

    var manager: DownloadManager? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_invoice_summary)

        binding.header.ivBack.setOnClickListener(View.OnClickListener {
            finish()
        })

        binding.header.tvHeaderText.setText("Invoice Summary")












        val data = intent.extras

        selectedInvoiceListData = intent.getStringExtra("loaderInvoiceDetails").toString()
        selectedInvoiceLoaderBookingId = intent.getStringExtra("loaderInvoiceBookingId").toString()
    //    selectedInvoiceListData = data?.getParcelable<LoaderInvoiceData>("loaderInvoiceDetails")
   //     selectedPassengerListData = data?.getParcelable<PassengerInvoiceData>("loaderInvoiceDetails")

        //Log.d("TAG___", "onCreate: " + selectedInvoiceListData!!.invoiceNumber.toString())

        viewModel.progressBarStatus.observe(this) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }

        viewModel.loaderInvoiceSummaryDetailResponse.observe(this) {
            if (it.status == 1) {
                // toast("booking Successful")
                toast(it.message!!)

                binding.tvInvoiceNumber.text = it.data[0].invoiceNumber
                binding.tvPaymentDate.text = it.data[0].bookingDate
                binding.tvInvoiceDate.text = it.data[0].createdAt
                binding.tvInvoiceTime.text = it.data[0].createdAt

                binding.tvUsername.text = it.userDetails?.name
                binding.tvUserphone.text = it.userDetails?.mobileNumber
                binding.tvUseremail.text = it.userDetails?.email

                binding.tvVehicleType.text = it.data[0].bookingTime
                binding.tvBodyType.text = it.data[0].bodyType
                binding.tvVehicleNumber.text = it.data[0].vehicleNumber
                binding.tvTotalLoads.text = it.data[0].bookingTime
                binding.tvPartyOwnerName.text = it.ownerDetails?.name
                binding.tvPartyOwnderNumber.text = it.ownerDetails?.mobile
                binding.tvDriverName.text = it.data[0].bookingTime
                binding.tvDriverNumber.text = it.data[0].bookingTime

                binding.tvDepartureplace.text = it.data[0].picupLocation
                binding.tvArrivalplace.text = it.data[0].dropLocation
                binding.tvBookingDate.text = it.data[0].bookingDate
                binding.tvCompleteDate.text = it.data[0].bookingDate
                binding.tvCharges.text = it.data[0].bookingDate
                binding.tvGst.text = it.data[0].bookingDate
                binding.tvCgst.text = it.data[0].bookingTime

                binding.tvTotalamount.text = it.data[0].fare


                if(it.data[0].paymentMode.equals("1"))
                {binding.tvPaymentMode.setText("Cash")}
                else  if(it.data[0].paymentMode.equals("2"))
                {binding.tvPaymentMode.setText("Online")}




//                binding.tvDate.text = it.data[0].booking_date
//                binding.tvTime.text = it.data[0].bookingTime
//                binding.tvPickup.text = it.data[0].picupLocation
//                binding.tvDropoff.text = it.data[0].dropLocation
//                binding.tvVehicleType.text = it.data[0].vehicleName
//                binding.tvBodyType.text = it.data[0].bodyType
//                binding.tvVehicleNumber.text = it.data[0].vehicleNumber
//                binding.tvTotalLoads.text = it.data[0].vehicleNumber
//                binding.tvPartyName.text = it.data[0].vehicleNumber
//                binding.tvPartyNumber.text = it.data[0].vehicleNumber
//
//
//
//                binding.tvDriverName.text = it.ownerDetails?.name
//                binding.tvDriverPhone.text = it.ownerDetails?.mobile
//                // binding.tvRidesNumber.text = it.data[0].r
//                binding.tvUsername.text = it.userDetails!!.name
//                binding.tvUserphone.text = it.userDetails!!.mobileNumber
//                binding.tvUseremail.text = it.userDetails!!.email
//
//
//



                //  userPref.setDriverId(it.data[0]!!.driverId.toString())

            } else {
                toast(it.message!!)
            }
        }




        viewModel.loaderInvoiceDetailApi(
            "Bearer " + userPref.user.apiToken,
            selectedInvoiceListData.toString()
        )












        viewModel.loaderSendMailResponseModel.observe(this) {
            if (it.status == 1) {
                // toast("booking Successful")
                toast("Email Sent L successfully!")

            } else {
                toast(it.message!!)
            }
        }
        binding.btnEmail.setOnClickListener(View.OnClickListener {
            viewModel.sendMailLoaderInvoiceApi("Bearer " + userPref.user.apiToken, selectedInvoiceLoaderBookingId.toString())
        })


        viewModel.loaderDownloadInvoiceResponseModel.observe(this) {
            if (it.status == 1) {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(it.url)))
                toast("Invoice Downloaded successfully!")
            } else {
                toast(it.message!!)
            }
        }
        binding.btnDownload.setOnClickListener(View.OnClickListener {
            viewModel.loaderDownloadInvoiceUrlApi("Bearer " + userPref.user.apiToken,
                selectedInvoiceLoaderBookingId!!
            )
        })












    }


}

