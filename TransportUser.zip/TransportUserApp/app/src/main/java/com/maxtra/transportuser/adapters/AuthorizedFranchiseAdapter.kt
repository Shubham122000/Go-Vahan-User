package com.maxtra.transportuser.adapters

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.maxtra.transportuser.R
import com.maxtra.transportuser.activities.authorizedfranchise.AuthorizedFranchisesActivity
import com.maxtra.transportuser.databinding.RowAuthorizedFranchiseBinding
import com.maxtra.transportuser.model.authorizedfranchisesmodel.AuthorizedFranchisesData
import com.maxtra.transportuser.model.loaderinvoicelistmodel.LoaderInvoiceData
import com.maxtra.transportuser.model.searchPassengerVehicle.SearchPassengerData

class AuthorizedFranchiseAdapter(
    var context: Context,
    val list: List<AuthorizedFranchisesData>
    , private val listener: AuthorizedFranchisesActivity
) : RecyclerView.Adapter<AuthorizedFranchiseAdapter.ViewHolder>() {

    inner  class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        var binding: RowAuthorizedFranchiseBinding = DataBindingUtil.bind(itemView)!!

    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.row_authorized_franchise, parent, false)
        return ViewHolder(itemView)    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        val data = list[position]

        /*holder.binding.linearItem.setOnClickListener(View.OnClickListener {
          val intent = Intent(context, TripDetailsActivity::class.java)
          intent.putExtra("orderType", "4")
            context.startActivity(intent)
        })*/



        holder.binding.tvAddress.text = data.ownerName
        holder.binding.tvEmail.text = data.emailId
        holder.binding.tvOwnerName.text = data.ownerName
        holder.binding.tvPhn.text = data.mobileNo
       // holder.binding.tvAvailable.text = data.mobileNo
        holder.binding.ivCompanyLogo
        Glide.with(context)
            .load(data.logo)
            .error(R.drawable.image_placeholder)
            .into(holder.binding.ivCompanyLogo)
        holder.binding.btnCall.setOnClickListener {
            data.mobileNo.toString().let { it1 -> listener.onCallNowClicked(it1) }
        }


    }

    override fun getItemCount(): Int {
        return list.size
    }


    interface OnClick{

        fun onCallNowClicked(number : String)

    }


}