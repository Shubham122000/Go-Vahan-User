package com.maxtra.transportuser.activities.referearn

import android.os.Bundle
import android.view.View
import androidx.databinding.DataBindingUtil
import com.maxtra.transportuser.R
import com.maxtra.transportuser.baseClasses.BaseActivity
import com.maxtra.transportuser.databinding.ActivityReferEarnBinding

class ReferEarnActivity : BaseActivity() {
    private lateinit var binding : ActivityReferEarnBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_refer_earn)

        binding.header.ivBack.setOnClickListener(View.OnClickListener {
            finish()
        })

        binding.header.tvHeaderText.setText("Refer & Earn")


    }
}