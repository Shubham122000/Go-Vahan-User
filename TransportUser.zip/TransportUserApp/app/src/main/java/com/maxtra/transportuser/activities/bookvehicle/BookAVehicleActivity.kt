package com.maxtra.transportuser.activities.bookvehicle

import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatDelegate
import androidx.databinding.DataBindingUtil
import com.maxtra.transportuser.R
import com.maxtra.transportuser.adapters.ViewPagerAdapter
import com.maxtra.transportuser.baseClasses.BaseActivity
import com.maxtra.transportuser.databinding.ActivityBookAvehicleBinding
import com.maxtra.transportuser.model.getfavouritelocation.GetFavouriteLocationData
import com.maxtra.transportuser.model.passengerinvoicelistmodel.PassengerInvoiceData
import com.maxtra.transportuser.model.tripmanagementpassengermodel.PassengerTripManagementData
import dagger.hilt.android.AndroidEntryPoint


@AndroidEntryPoint
class BookAVehicleActivity : BaseActivity() {

    lateinit var binding : ActivityBookAvehicleBinding

    private var pagerAdapter: ViewPagerAdapter? = null

    companion object{
        var selectedPassengerTripData: GetFavouriteLocationData? = null
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
       // setContentView(R.layout.activity_book_avehicle)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

        binding = DataBindingUtil.setContentView(this, R.layout.activity_book_avehicle)

        binding.header.ivBack.setOnClickListener(View.OnClickListener {
            finish()

        })


        binding.header.tvHeaderText.setText("Vehicle Booking")




        if(intent.extras!=null) {
            val data = intent.extras
            selectedPassengerTripData =
                data?.getParcelable<GetFavouriteLocationData>("favouriteLocation")
            Log.d("TAG___", "onCreate: " + selectedPassengerTripData!!.pickAddress.toString())

        }

        setTab()

    }

    private fun setTab() {
        binding.tabLayout.addTab(binding.tabLayout.newTab().setText("Loader"))
        binding.tabLayout.addTab(binding.tabLayout.newTab().setText("Passenger"))
        //  binding.tabLayout.addTab(binding.tabLayout.newTab().setText("Request Completed"))



        /*for (i in 0 until  binding.tabLayout.getTabCount()) {
            val tab = ( binding.tabLayout.getChildAt(0) as ViewGroup).getChildAt(i)
            val p = tab.layoutParams as ViewGroup.MarginLayoutParams
            p.setMargins(0, 0, 0, 0)
            tab.requestLayout()
        }
        binding.tabLayout.getChildAt(0)

        binding.viewPager.adapter = pagerAdapter
        binding.tabLayout.setupWithViewPager(binding.viewPager)*/



        pagerAdapter = ViewPagerAdapter(supportFragmentManager)
        binding.viewPager.adapter = pagerAdapter
        binding.tabLayout.setupWithViewPager(binding.viewPager)


        binding.tabLayout.getChildAt(0)

        binding.viewPager.adapter = pagerAdapter
        binding.tabLayout.setupWithViewPager(binding.viewPager)
    }


}