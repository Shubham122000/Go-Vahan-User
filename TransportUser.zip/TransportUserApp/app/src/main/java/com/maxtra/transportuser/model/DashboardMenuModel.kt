package com.maxtra.transportuser.model

data class DashboardMenuModel(val title: String){


}

