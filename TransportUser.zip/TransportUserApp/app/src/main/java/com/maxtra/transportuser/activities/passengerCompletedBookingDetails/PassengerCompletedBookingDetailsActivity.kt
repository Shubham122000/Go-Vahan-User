package com.maxtra.transportuser.activities.passengerCompletedBookingDetails

import android.app.Dialog
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.CheckBox
import androidx.activity.viewModels
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.LinearLayoutManager
import com.maxtra.transportuser.R

import com.maxtra.transportuser.adapters.PassengerCancelTripReasonAdapter
import com.maxtra.transportuser.baseClasses.BaseActivity
import com.maxtra.transportuser.databinding.ActivityPassengerCompletedBookingDetailsBinding
import com.maxtra.transportuser.databinding.BottomSheetCancelTripBinding
import com.maxtra.transportuser.databinding.BottomSheetRidecancellationBinding
import com.maxtra.transportuser.model.completedpassengertriphistorymodel.CompletedPassengerHistoryData
import com.maxtra.transportuser.model.passengercancelreasonmodel.PassengerCancelReasonData
import com.maxtra.transportuser.util.toast


class PassengerCompletedBookingDetailsActivity : BaseActivity() {


    private lateinit var binding : ActivityPassengerCompletedBookingDetailsBinding
    private var selectedPassengerCompletedHistoryData: CompletedPassengerHistoryData? = null
    private val viewModel: PassengerCompletedBookingDetailsViewModel by viewModels()



    private var listData: ArrayList<PassengerCancelReasonData> = ArrayList()
    private var passengerCancelReasonAdapter: PassengerCancelTripReasonAdapter? = null
    var crnNumber = ""
    private var listReasonType_id:ArrayList<String> = ArrayList()
    var reasontypevalue_id: String? = ""
    private lateinit var str: String




    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = DataBindingUtil.setContentView(this, R.layout.activity_passenger_completed_booking_details)

        binding.header.ivBack.setOnClickListener(View.OnClickListener {
            finish()
        })

        binding.header.tvHeaderText.setText("Booking Details")


        val data = intent.extras
        selectedPassengerCompletedHistoryData = data?.getParcelable<CompletedPassengerHistoryData>("passengerCompletedHistoryDetails")

        Log.d("TAG___", "onCreate: " + selectedPassengerCompletedHistoryData!!.bookingId.toString())

        viewModel.progressBarStatus.observe(this) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }

        viewModel.passengerCompletedHistoryDetailResponse.observe(this) {
            if (it.status == 1) {
                // toast("booking Successful")
                toast(it.message!!)


                binding.tvBookingId.text = it.data[0].bookingId
                binding.tvTripStatus.text = it.data[0].bookingStatus
                binding.tvPaid.text = it.data[0].fare

                if(it.data[0].paymentMode.equals("1"))
                {binding.tvPaymentMethod.setText("Cash")}
                else  if(it.data[0].paymentMode.equals("2"))
                {binding.tvPaymentMethod.setText("Online")}



                binding.tvBookingId.text = it.data[0].bookingId
                binding.tvTripStatus.text = it.data[0].bookingStatus
                binding.tvDate.text = it.data[0].bookingDate
                binding.tvTime.text = it.data[0].bookingTime
                binding.tvPickup.text = it.data[0].picupLocation
                binding.tvDropoff.text = it.data[0].dropLocation
                binding.tvVehicleType.text = it.data[0].vehicleName
                binding.tvBodyType.text = it.data[0].bodyType
                binding.tvVehicleNumber.text = it.data[0].vehicleNumber
                binding.tvTotalLoads.text = it.data[0].vehicleNumber
                binding.tvPartyName.text = it.data[0].vehicleNumber





//                binding.tvDate.text = it.data[0].booking_date
//                binding.tvTime.text = it.data[0].bookingTime
//                binding.tvPickup.text = it.data[0].picupLocation
//                binding.tvDropoff.text = it.data[0].dropLocation
//                binding.tvVehicleType.text = it.data[0].vehicleName
//                binding.tvBodyType.text = it.data[0].bodyType
//                binding.tvVehicleNumber.text = it.data[0].vehicleNumber
//                binding.tvTotalLoads.text = it.data[0].vehicleNumber
//                binding.tvPartyName.text = it.data[0].vehicleNumber
//                binding.tvPartyNumber.text = it.data[0].vehicleNumber
//
//
//
//                binding.tvDriverName.text = it.ownerDetails?.name
//                binding.tvDriverPhone.text = it.ownerDetails?.mobile
//                // binding.tvRidesNumber.text = it.data[0].r
//                binding.tvUsername.text = it.userDetails!!.name
//                binding.tvUserphone.text = it.userDetails!!.mobileNumber
//                binding.tvUseremail.text = it.userDetails!!.email
//
//
//



                //  userPref.setDriverId(it.data[0]!!.driverId.toString())

            } else {
                toast(it.message!!)
            }
        }




        viewModel.passengerOngoingHistoryDetailApi(
            "Bearer " + userPref.user.apiToken,
            selectedPassengerCompletedHistoryData?.bookingId!!
        )


        viewModel.getPassengerCancelReasonListApi("Bearer " + userPref.user.apiToken)




        binding.btnRaiseComplaint.setOnClickListener(View.OnClickListener {

            /*val intent = Intent(this, PassengerRaiseComplaintActivity::class.java)
            intent.putExtra("BookingId", selectedPassengerCompletedHistoryData?.bookingId!!.toString())
            startActivity(intent)*/


        })








    }







}

