package com.maxtra.transportuser.adapters

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.maxtra.transportuser.R
import com.maxtra.transportuser.customclick.walletcustomclick
import com.maxtra.transportuser.databinding.RowWalletListBinding
import com.maxtra.transportuser.model.loaderwalletlistmodel.LoaderWalletListData
import com.maxtra.transportuser.util.DateFormat

class LoaderWalletAdapter (val list: List<LoaderWalletListData>,var wallet_customclick:walletcustomclick
) : RecyclerView.Adapter<LoaderWalletAdapter.ViewHolder>() {

    inner  class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        var binding: RowWalletListBinding = DataBindingUtil.bind(itemView)!!

    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.row_wallet_list, parent, false)
        return ViewHolder(itemView)    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        val data = list[position]
       try {
           holder.binding.tvAmount.text = " ₹${data.amount}"

           holder.binding.tvDate.text = DateFormat.TimeFormat(data.transaction_date)
           if (holder.binding.tvDate.text==""){
               holder.binding.tvDate.text = data.transaction_date

           }
           if (data.debit== "debit") {
               holder.binding.tvName.text = "Money Paid to ${data.name}"
           }
          else if (data.credit=="credit"){
               holder.binding.tvName.text = "Money added to wallet"

           }
           holder.binding.linearItem.setOnClickListener {
               wallet_customclick.onItemClick(data.user_id.toString())

           }
       }catch (e:Exception){
           e.printStackTrace()
       }
    }

    override fun getItemCount(): Int {
        return list.size
    }


}