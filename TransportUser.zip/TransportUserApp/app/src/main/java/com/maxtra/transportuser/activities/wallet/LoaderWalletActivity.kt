package com.maxtra.transportuser.activities.wallet

import android.annotation.SuppressLint
import android.app.Activity
import android.app.DatePickerDialog
import android.app.Dialog
import android.content.ContentValues.TAG
import android.icu.text.SimpleDateFormat
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.*
import android.widget.Toast
import androidx.activity.viewModels
import androidx.annotation.RequiresApi
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.LinearLayoutManager
import com.maxtra.transportuser.R
import com.maxtra.transportuser.adapters.LoaderWalletAdapter
import com.maxtra.transportuser.adapters.LoaderWalletFilterAdapter
import com.maxtra.transportuser.baseClasses.BaseActivity
import com.maxtra.transportuser.databinding.ActivityWalletBinding
import com.maxtra.transportuser.databinding.DialogAddMoneyLoaderBinding
import com.maxtra.transportuser.model.loaderwalletfiltermodel.LoaderWalletFilterData
import com.maxtra.transportuser.model.loaderwalletlistmodel.LoaderWalletListData
import com.maxtra.transportuser.util.toast
import dagger.hilt.android.AndroidEntryPoint
import java.util.*
import android.view.MenuItem;
import android.widget.PopupMenu;
import com.maxtra.transportuser.customclick.walletcustomclick
import com.razorpay.Checkout
import com.razorpay.PaymentData
import com.razorpay.PaymentResultWithDataListener
import org.json.JSONObject


@AndroidEntryPoint
class LoaderWalletActivity : BaseActivity(),PopupMenu.OnMenuItemClickListener,walletcustomclick,
    PaymentResultWithDataListener {
    private lateinit var binding : ActivityWalletBinding
    private val viewModel : LoaderWalletViewModel by viewModels()
    private var listData: ArrayList<LoaderWalletListData> = ArrayList()
    private var filterlistData: ArrayList<LoaderWalletFilterData> = ArrayList()
    private var loaderWalletAdapter : LoaderWalletAdapter ?= null
    private var loaderWalletFilterAdapter : LoaderWalletFilterAdapter ?= null
    lateinit var bindingDialog: DialogAddMoneyLoaderBinding

    var pos = ""
    var selectedDateFormat2 = ""
    var transactionid=""
    var amount: Int = 0
    var finalPamountInt = 0
    @RequiresApi(Build.VERSION_CODES.N)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_wallet)

        binding.ivBack.setOnClickListener(View.OnClickListener {
            finish()
        })

        binding.tvHeaderText.setText("Wallet")

        binding.btnAddMoney.setOnClickListener(View.OnClickListener {
            addMoneyDialog()
        })

        viewModel.addmoneytowalletresponse.observe(this) {
            if (it.status == 1) {
                toast("Successfully added.")
                viewModel.loaderWalletListApi(
                    "Bearer "+userPref.getToken().toString(),
                )
            } else {
                toast(it.message!!)
            }
        }



        viewModel.progressBarStatus.observe(this) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }

        binding.btnDownload.setOnClickListener {

            viewModel.loaderWalletDownload("Bearer " + userPref.user.apiToken)

        }



        viewModel.getLoaderWalletListResponse.observe(this) {
            if (it.status == 1) {
                listData.clear()
                // listData!!.addAll(it.getFavLocdata)

                if (it.data.isEmpty() ) {
                    binding.idNouser.visibility = View.VISIBLE
                    binding.rvWallet.visibility = View.GONE
                    binding.llDownload.visibility = View.GONE

                }
                else {
                    binding.idNouser.visibility = View.GONE
                    binding.rvWallet.visibility = View.VISIBLE
                    binding.llDownload.visibility = View.VISIBLE

                    listData.addAll(it.data)
                    loaderWalletAdapter = LoaderWalletAdapter(listData,this)
                    binding.rvWallet.apply {
                        adapter = loaderWalletAdapter
                        layoutManager = LinearLayoutManager(this@LoaderWalletActivity)


                        binding.tvBalance.text = "₹${it.TotalAmount.toString()}"


                        // it.getFavLocdata?.let { notificationList?.addAll(it) }
                        //    favouriteLocationsAdapter?.notifyDataSetChanged()

                    }
                    //   favouriteLocationsAdapter?.notifyDataSetChanged()
                }

            } else   {
                Log.d("Response", it.toString())
                toast(it.message!!)
            }
        }
        viewModel.downloadloaderlist.observe(this) {
            if (it.status == 1) {
                toast(it.message!!)

            } else   {
                toast(it.message!!)
            }
        }

        viewModel.loaderWalletListApi("Bearer " + userPref.user.apiToken)












        viewModel.loaderWalletFilterListResponse.observe(this) {
            if (it.status == 1) {
                filterlistData.clear()
                // listData!!.addAll(it.getFavLocdata)

                if (it.data.isEmpty() ) {
                    binding.idNouser.visibility = View.VISIBLE
                    binding.rvWallet.visibility = View.GONE
                    binding.llDownload.visibility = View.GONE

                }
                else {
                    binding.idNouser.visibility = View.GONE
                    binding.rvWallet.visibility = View.VISIBLE
                    binding.llDownload.visibility = View.VISIBLE
                    filterlistData.addAll(it.data)
                    loaderWalletFilterAdapter = LoaderWalletFilterAdapter(filterlistData)
                    binding.rvWallet.apply {
                        adapter = loaderWalletFilterAdapter
                        layoutManager = LinearLayoutManager(this@LoaderWalletActivity)

                        // it.getFavLocdata?.let { notificationList?.addAll(it) }
                        //    favouriteLocationsAdapter?.notifyDataSetChanged()

                    }
                    //   favouriteLocationsAdapter?.notifyDataSetChanged()
                }

            } else   {
                Log.d("Response", it.toString())
                toast(it.message!!)
            }
        }



















    }


    fun showPopup(v: View?) {
        val popup = PopupMenu(this, v)
        popup.setOnMenuItemClickListener(this)
        popup.inflate(R.menu.menu_filter_wallet)
        popup.show()
    }
    @RequiresApi(Build.VERSION_CODES.N)
    override fun onMenuItemClick(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.menu_all -> {
               // Toast.makeText(this, "Item 1 clicked", Toast.LENGTH_SHORT).show()
                viewModel.loaderWalletListApi("Bearer " + userPref.user.apiToken)
                true
            }
            R.id.menu_chooseDate -> {
                clickDataPicker()
                true
            }

            R.id.menu_debit -> {
                viewModel.loaderWalletFilterApi("Bearer " + userPref.user.apiToken, "","2")
                true
            }
            R.id.menu_credit -> {
                viewModel.loaderWalletFilterApi("Bearer " + userPref.user.apiToken, "","1")

                true
            }


            else -> false
        }
    }





    /*override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_filter_wallet, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.getItemId() === R.id.menu_all) {
            toast("menu_all")
            return true
        } else if (item.getItemId() === R.id.menu_chooseDate) {
            toast("menu_chooseDate")
            return true
        }
        return super.onOptionsItemSelected(item)
    }*/


    private fun addMoneyDialog() {
        val cDialog = Dialog(this, R.style.Theme_Tasker_Dialog)
         bindingDialog= DataBindingUtil.inflate(
                    LayoutInflater.from(this),
             R.layout.dialog_add_money_loader,
             null,
             false
        )
        cDialog.setContentView(bindingDialog.root)
        cDialog.setCancelable(false)
        cDialog.window!!.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        cDialog.show()
        viewModel.addMoneyWalletResponse.observe(this) {
            if (it.status == 1) {
                toast(it.message!!)

            } else {
                Log.d("Response", it.toString())
                toast(it.message!!)
            }
        }
        bindingDialog.btnProceed.setOnClickListener {
            if(bindingDialog.edtAmount.text.toString().isBlank()){
                toast(this , "Please enter amount.")
            }
            else{
                startPayment()
            }
            cDialog.dismiss()
            viewModel.loaderWalletListApi("Bearer " + userPref.user.apiToken)
        }
    }


    @SuppressLint("SimpleDateFormat")
    @RequiresApi(Build.VERSION_CODES.N)
    fun clickDataPicker() {
        val cal = Calendar.getInstance()
        val simpleDateFormat = SimpleDateFormat("dd-MM-yyyy")
        val simpleDateFormat2 = SimpleDateFormat("yyyy-MM-dd")
        cal.timeZone = TimeZone.getTimeZone("UTC")

        val datePickerDialog = DatePickerDialog(
            this,R.style.DatePickerTheme, { view, year, monthOfYear, dayOfMonth ->
                cal.set(year, monthOfYear, dayOfMonth)
               // binding.tvBookingdate.text = simpleDateFormat.format(cal.time)
                selectedDateFormat2 = simpleDateFormat2.format(cal.time)

                viewModel.loaderWalletFilterApi("Bearer " + userPref.user.apiToken, selectedDateFormat2,"")
                Log.d(TAG, "clickDataPicker: "+"Bearer " + userPref.user.apiToken+ selectedDateFormat2)

            },
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH),
            cal.get(Calendar.DAY_OF_MONTH)
        )
//        datePickerDialog.datePicker.minDate = System.currentTimeMillis()
        datePickerDialog.show()
    }

    override fun onItemClick(id: String) {
        transactionid=id
    }

    private fun startPayment()  {

        amount = ( bindingDialog.edtAmount.text.toString().replace("₹", "").toFloat() * 100).toInt()
        finalPamountInt = amount

        val activity: Activity = this
        val co = Checkout()
        co.setKeyID("rzp_test_ERu25JeZGdnYjs")
        try {
            var options = JSONObject()
            options.put("name", userPref.user.name)
            options.put("description", "Demoing Charges")
            //You can omit the image option to fetch the image from dashboard
            options.put("image", "https://s3.amazonaws.com/rzp-mobile/images/rzp.png")
            options.put("theme.color", "")
            options.put("currency", "INR")
            options.put("amount", finalPamountInt)
            options.put("send_sms_hash", true)

            val prefill = JSONObject()
            prefill.put("email", userPref.user.email)
            prefill.put("contact", userPref.user.mobileNumber)

            options.put("prefill", prefill)

            co.open(this@LoaderWalletActivity, options)
        } catch (e: Exception) {
            Toast.makeText(activity, "Error in payment: " + e.message, Toast.LENGTH_LONG).show()
            e.printStackTrace()
        }
    }


    override fun onPaymentSuccess(p0: String?, p1: PaymentData?) {
        viewModel.my_wallet_payment(
            "Bearer " + userPref.user.apiToken,"1",p1?.paymentId!!,bindingDialog.edtAmount.text.toString()

        )

    }

    override fun onPaymentError(p0: Int, p1: String?, p2: PaymentData?) {
        try {
            Toast.makeText(
                this,
                "Payment Unsuccessful", Toast.LENGTH_LONG
            ).show()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

}