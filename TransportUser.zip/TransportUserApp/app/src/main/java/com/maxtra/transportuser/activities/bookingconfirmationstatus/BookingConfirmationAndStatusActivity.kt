package com.maxtra.transportuser.activities.bookingconfirmationstatus

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.databinding.DataBindingUtil
import com.maxtra.transportuser.R
import com.maxtra.transportuser.activities.DashboardActivity
import com.maxtra.transportuser.activities.bookingreview.BookingReviewActivity
import com.maxtra.transportuser.baseClasses.BaseActivity
import com.maxtra.transportuser.databinding.ActivityBookingConfirmationAndStatusBinding
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class BookingConfirmationAndStatusActivity : BaseActivity() {
    private lateinit var binding : ActivityBookingConfirmationAndStatusBinding
    var paymentMode:String?=null
    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_booking_confirmation_and_status)
        binding.header.tvHeaderText.text = "Confirmation"
        if (intent!=null){
            paymentMode=intent.getStringExtra("payment_mode")
//            if (paymentMode.equals("cash")){
//                binding.tvRideCode.text = BookingReviewActivity.bookingLoaderRideCode
//                for (i in 0 until  BookingReviewActivity.bookingLoaderDataList.size){
//                    binding.bookingid.text = "Booking Id: #"+ BookingReviewActivity.bookingLoaderDataList[i].bookingId
//                    binding.tvBookingCreatedate.text = BookingReviewActivity.bookingLoaderDataList[i].createdAt
//
//                    // binding.tvVehicleName.text = BookingReviewActivity.bookingLoaderDataList[i].vehicleName
//                    binding.tvFrom.text = BookingReviewActivity.bookingLoaderDataList[i].picupLocation
//                    binding.tvTo.text = BookingReviewActivity.bookingLoaderDataList[i].dropLocation
//                    binding.tvVehicleNumber.text = BookingReviewActivity.bookingLoaderDataList[i].vehicleNumbers
//                    binding.tvRating.text = BookingReviewActivity.bookingLoaderDataList[i].rating
//                    binding.tvType.text = BookingReviewActivity.bookingLoaderDataList[i].bodyType
//                    binding.tvCapacity.text = BookingReviewActivity.bookingLoaderDataList[i].capacity
//                    binding.tvDistance.text = BookingReviewActivity.bookingLoaderDataList[i].distance
//                 //   binding.tvOwner.text = BookingReviewActivity.bookingLoaderDataList[i].o
//                    binding.tvBookingdate.text = BookingReviewActivity.bookingLoaderDataList[i].bookingDate
//                    binding.tvBookingtime.text = BookingReviewActivity.bookingLoaderDataList[i].bookingTime
//                    binding.tvAmount.text = BookingReviewActivity.bookingLoaderDataList[i].fare
//                    // binding.tvPaymentmode.text = BookingReviewActivity.bookingLoaderDataList[i].bookingDate
//
//                    /*if(BookingReviewActivity.bookingLoaderDataList[i].paymentMode.equals("1"))
//                    {binding.tvPaymentmode.setText("Cash")}
//                    else  if(BookingReviewActivity.bookingLoaderDataList[i].paymentMode.equals("2"))
//                    {binding.tvPaymentmode.setText("Online")}*/
////                    if(BookingReviewActivity.bookingLoaderDataList[i].bookingStatus.equals("1")){
//                        binding.tvBookingStatus.text = "Partial Payment Completed"
////                    }
////                    else if(BookingReviewActivity.bookingLoaderDataList[i].bookingStatus.equals("2")){
////                        binding.tvBookingStatus.text = "Accepted"
////                    }
////                    else if(BookingReviewActivity.bookingLoaderDataList[i].bookingStatus.equals("3")){
////                        binding.tvBookingStatus.text = "Cancel"
////                    }
////                    else if(BookingReviewActivity.bookingLoaderDataList[i].bookingStatus.equals("4")){
////                        binding.tvBookingStatus.text = "Completed"
////                    }
//
//                    /*if(BookingReviewActivity.bookingLoaderDataList[i].available.toString().equals("0")){
//                        binding.tvAvailable.text = "Not Available"
//                        binding.tvAvailable.visibility = View.VISIBLE
//                        binding.ivCheck.visibility = View.GONE
//                    }
//                    else if(it.data[0].available.toString().equals("1")){
//                        binding.tvAvailable.text = "Available"
//                        binding.tvAvailable.visibility = View.VISIBLE
//                        binding.ivCheck.visibility = View.VISIBLE
//                    }*/
//
//                }
//                for (i in 0 until  BookingReviewActivity.bookingLoaderUserList.size) {
//                    binding.tvUsreName.text = BookingReviewActivity.bookingLoaderUserList[i].name
//                    binding.tvUserPhone.text = BookingReviewActivity.bookingLoaderUserList[i].mobileNumber
//                    binding.tvUserEmail.text = BookingReviewActivity.bookingLoaderUserList[i].email
//                }
//                for (i in 0 until  BookingReviewActivity.bookingLoaderDriverList.size) {
//                    binding.tvDriverNam.text = BookingReviewActivity.bookingLoaderDriverList[i].name
//                    binding.tvDrivername.text = BookingReviewActivity.bookingLoaderDriverList[i].name
//                    binding.tvDriverphone.text = BookingReviewActivity.bookingLoaderDriverList[i].mobileNumber
//                }
//            }
//            else
                if (paymentMode.equals("online")){

                for (i in 0 until  BookingReviewActivity.bookingLoaderOnlineDataList.size){
                    binding.tvRideCode.text = BookingReviewActivity.bookingLoaderOnlineDataList[i].ride_code
                    binding.bookingid.text = "Booking Id: #"+ BookingReviewActivity.bookingLoaderOnlineDataList[i].bookingId
                    binding.tvBookingCreatedate.text = BookingReviewActivity.bookingLoaderOnlineDataList[i].createdAt
                    // binding.tvVehicleName.text = BookingReviewActivity.bookingLoaderOnlineDataList[i].vehicleName
                    binding.tvFrom.text = BookingReviewActivity.bookingLoaderOnlineDataList[i].picupLocation
                    binding.tvTo.text = BookingReviewActivity.bookingLoaderOnlineDataList[i].dropLocation
                    binding.tvVehicleNumber.text = BookingReviewActivity.bookingLoaderOnlineDataList[i].vehicleNumbers
                    binding.tvRating.text = BookingReviewActivity.bookingLoaderOnlineDataList[i].rating
                    binding.tvType.text = BookingReviewActivity.bookingLoaderOnlineDataList[i].bodyType
                    binding.tvCapacity.text = BookingReviewActivity.bookingLoaderOnlineDataList[i].capacity
                    binding.tvDistance.text = BookingReviewActivity.bookingLoaderOnlineDataList[i].distance
                    //   binding.tvOwnerName.text = BookingReviewActivity.bookingLoaderOnlineDataList[i].ow
                    binding.tvBookingdate.text = BookingReviewActivity.bookingLoaderOnlineDataList[i].bookingDate
                    binding.tvBookingtime.text = BookingReviewActivity.bookingLoaderOnlineDataList[i].bookingTime
                    binding.tvAmount.text = BookingReviewActivity.bookingLoaderOnlineDataList[i].fare
                    binding.tvPaymentmode.text = "Online"
                    binding.tvBookingStatus.text = "Partial Payment Completed"
                    // binding.tvPaymentmode.text = BookingReviewActivity.bookingLoaderOnlineDataList[i].bookingDate
                    /*if(BookingReviewActivity.bookingLoaderOnlineDataList[i].paymentMode.equals("1"))
                    {binding.tvPaymentmode.setText("Cash")}
                    else  if(BookingReviewActivity.bookingLoaderOnlineDataList[i].paymentMode.equals("2"))
                    {binding.tvPaymentmode.setText("Online")}*/

//                    if(BookingReviewActivity.bookingLoaderOnlineDataList[i].bookingStatus.equals("1")){

//                    }
//                    else if(BookingReviewActivity.bookingLoaderOnlineDataList[i].bookingStatus.equals("2")){
//                        binding.tvBookingStatus.text = "Accepted"
//                    }
//                    else if(BookingReviewActivity.bookingLoaderOnlineDataList[i].bookingStatus.equals("3")){
//                        binding.tvBookingStatus.text = "Cancel"
//                    }
//                    else if(BookingReviewActivity.bookingLoaderOnlineDataList[i].bookingStatus.equals("4")){
//                        binding.tvBookingStatus.text = "Completed"
//                    }

                    /*if(BookingReviewActivity.bookingLoaderOnlineDataList[i].available.toString().equals("0")){
                        binding.tvAvailable.text = "Not Available"
                        binding.tvAvailable.visibility = View.VISIBLE
                        binding.ivCheck.visibility = View.GONE
                    }
                    else if(it.data[0].available.toString().equals("1")){
                        binding.tvAvailable.text = "Available"
                        binding.tvAvailable.visibility = View.VISIBLE
                        binding.ivCheck.visibility = View.VISIBLE
                    }*/

                }
                for (i in 0 until  BookingReviewActivity.bookingLoaderOnlineUserList.size) {
                    binding.tvUsreName.text = BookingReviewActivity.bookingLoaderOnlineUserList[i].name
                    binding.tvUserPhone.text = BookingReviewActivity.bookingLoaderOnlineUserList[i].mobileNumber
                    binding.tvUserEmail.text = BookingReviewActivity.bookingLoaderOnlineUserList[i].email
                }
                for (i in 0 until  BookingReviewActivity.bookingLoaderOnlineDriverList.size) {
                    binding.tvDriverNam.text = BookingReviewActivity.bookingLoaderOnlineDriverList[i].name
                    binding.tvDrivername.text = BookingReviewActivity.bookingLoaderOnlineDriverList[i].name
                    binding.tvDriverphone.text = BookingReviewActivity.bookingLoaderOnlineDriverList[i].mobileNumber
                }
            }
        }
        binding.header.ivBack.setOnClickListener(View.OnClickListener {
            finish()
        })
        binding.header.tvHeaderText.setText("Booking Confirmation & Status")


        binding.btnBack.setOnClickListener(View.OnClickListener {
            val intent = Intent(this, DashboardActivity::class.java)
            startActivity(intent)
            finish()
        })
    }
}