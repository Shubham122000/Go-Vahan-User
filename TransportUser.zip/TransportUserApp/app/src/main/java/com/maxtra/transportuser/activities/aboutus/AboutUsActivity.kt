package com.maxtra.transportuser.activities.aboutus

import android.os.Bundle
import android.view.View
import androidx.databinding.DataBindingUtil
import com.maxtra.transportuser.R
import com.maxtra.transportuser.baseClasses.BaseActivity
import com.maxtra.transportuser.databinding.ActivityAboutUsBinding

class AboutUsActivity : BaseActivity() {
    private lateinit var binding : ActivityAboutUsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_about_us)

        binding.header.ivBack.setOnClickListener(View.OnClickListener {
            finish()
        })

        binding.header.tvHeaderText.setText("About Us")


    }
}