package com.maxtra.transportuser.activities.bookingsuccess

import android.content.ContentValues.TAG
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.databinding.DataBindingUtil
import com.maxtra.transportuser.R
import com.maxtra.transportuser.activities.bookingconfirmationstatus.BookingConfirmationAndStatusActivity
import com.maxtra.transportuser.activities.bookingreview.BookingReviewActivity
import com.maxtra.transportuser.baseClasses.BaseActivity
import com.maxtra.transportuser.databinding.ActivityBookingSuccessBinding
import com.maxtra.transportuser.model.bookingloadermodel.BookingLoaderData
import com.maxtra.transportuser.model.bookingloadermodel.BookingLoaderDriver
import com.maxtra.transportuser.model.bookingloadermodel.BookingLoaderUser
import com.maxtra.transportuser.model.loaderpaymentsuccessmodel.LoaderPaymentSuccessData
import com.maxtra.transportuser.model.loaderpaymentsuccessmodel.LoaderPaymentSuccessDriver
import com.maxtra.transportuser.model.loaderpaymentsuccessmodel.LoaderPaymentSuccessUser
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class BookingSuccessActivity : BaseActivity() {
    private lateinit var binding : ActivityBookingSuccessBinding
    var modelDataList: BookingLoaderData?=null
    var modelUserList: BookingLoaderUser?=null
    var modelDriverList: BookingLoaderDriver?=null
    var modelRideCode = ""
    var modelOnlineDataList: LoaderPaymentSuccessData?=null
    var modelOnlineUserList: LoaderPaymentSuccessUser?=null
    var modelOnlineDriverList: LoaderPaymentSuccessDriver?=null
    var modelOnlineRideCode = ""
    var paymentMode:String?=null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_booking_success)

        if (intent!=null){
//            if(intent.getStringExtra("cash").equals("CASH")) {
//                modelOnlineDataList = (intent.getStringExtra("modelDataList") as LoaderPaymentSuccessData?)
//                modelOnlineUserList = (intent.getStringExtra("modelUserList") as LoaderPaymentSuccessUser?)
//                modelOnlineDriverList =
//                    (intent.getStringExtra("modelDriverList") as LoaderPaymentSuccessDriver?)
//                modelOnlineRideCode=intent.getStringExtra("modelRideCode").toString()
//                Log.d(TAG, "onCreatepay:"+"Cash")
//                paymentMode="cash"
//           }else
               if(intent.getStringExtra("online").equals("ONLINE")) {
                modelDataList = (intent.getStringExtra("modelDataList") as BookingLoaderData?)
                modelUserList = (intent.getStringExtra("modelUserList") as BookingLoaderUser?)
                modelDriverList =
                    (intent.getStringExtra("modelDriverList") as BookingLoaderDriver?)
                modelRideCode = (intent.getStringExtra("modelRideCode1") as String)
                Log.d(TAG, "onCreatepay:"+"Online")
                paymentMode="online"
            }
        }
//        val extras = intent.extras
//        if (extras != null) {
//
//            if() {
//                modelOnlineDataList = (extras.getSerializable("modelDataList") as LoaderPaymentSuccessData?)
//                modelOnlineUserList = (extras.getSerializable("modelUserList") as LoaderPaymentSuccessUser?)
//                modelOnlineDriverList =
//                    (extras.getSerializable("modelDriverList") as LoaderPaymentSuccessDriver?)
//                modelOnlineRideCode="1234"
//                Log.d(TAG, "onCreatepay:"+"Online")
//           }else if(!BookingReviewActivity.bPaymentMode) {
//
//                modelDataList = (extras.getSerializable("modelDataList") as BookingLoaderData?)
//                modelUserList = (extras.getSerializable("modelUserList") as BookingLoaderUser?)
//                modelDriverList =
//                    (extras.getSerializable("modelDriverList") as BookingLoaderDriver?)
//                modelRideCode = (extras.getSerializable("modelRideCode") as String)
//
//                Log.d(TAG, "onCreatepay:"+"Cash")
//            }
//
//
//
//
//
//        }

        binding.btnNext.setOnClickListener(View.OnClickListener {
            startActivity(Intent(this, BookingConfirmationAndStatusActivity :: class.java)
                .putExtra("modelDataList", modelDataList)
                .putExtra("modelUserList", modelUserList)
                .putExtra("modelDriverList", modelDriverList)
                .putExtra("modelRideCode", modelRideCode)
                .putExtra("payment_mode","online"))
            finish()
        })
    }
}