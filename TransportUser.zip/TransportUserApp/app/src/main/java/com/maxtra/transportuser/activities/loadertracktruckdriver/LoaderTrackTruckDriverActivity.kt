package com.maxtra.transportuser.activities.loadertracktruckdriver

import android.content.ContentValues.TAG
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.content.res.AppCompatResources
import androidx.databinding.DataBindingUtil
import com.bumptech.glide.Glide
import com.maxtra.transportuser.R
import com.maxtra.transportuser.activities.trackmap.TrackMapActivity
import com.maxtra.transportuser.baseClasses.BaseActivity
import com.maxtra.transportuser.databinding.ActivityLoaderTrackTruckDriverBinding
import com.maxtra.transportuser.util.toast
import dagger.hilt.android.AndroidEntryPoint


@AndroidEntryPoint
class LoaderTrackTruckDriverActivity : BaseActivity() {
    private lateinit var binding : ActivityLoaderTrackTruckDriverBinding
    private val viewModel : LoaderTrackTruckdriverViewModel by viewModels()
   // lateinit var getBookingId : String




    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_loader_track_truck_driver)

        binding.header.ivBack.setOnClickListener(View.OnClickListener {
            finish()
        })

        binding.header.tvHeaderText.setText("Track Truck Driver")

        binding.llLiveTracking.setOnClickListener(View.OnClickListener {
            val intent = Intent(this, TrackMapActivity::class.java)
            startActivity(intent)
        })




        val getBookingId = intent.getStringExtra("BookingId")





        viewModel.progressBarStatus.observe(this) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }




        viewModel.loaderLiveTrackingResponseModel.observe(this) {
            if (it.status == 1) {
                toast(it.message!!)
               // finish()

                binding.tvTruckName.text = it.data[0].vehicleName
                binding.tvWheeler.text = it.data[0].bookingDate
                binding.tvTruckNumber.text = it.data[0].vehicleNumbers
                binding.tvDriverName.text = it.data[0].driverName
                binding.tvDriverType.text = it.data[0].driverName
                binding.tvDrivePhone.text = it.data[0].driverName
                binding.tvFrom.text = it.data[0].picupLocation
                binding.tvFromdate.text = it.data[0].bookingDate
                binding.tvTo.text = it.data[0].dropLocation
                binding.tvTodate.text = it.data[0].bookingDate
                binding.tvTripStartedDate.text = it.data[0].bookingDate


                binding.tvTimeLeft.text = it.data[0].bookingDate + " left to reach destination"

                Glide.with(this).load(it.data[0].vehicleImage).into(binding.ivTruck)
                Glide.with(this).load(it.data[0].driverImage).into(binding.ivDriver)



                //     1=>pending, 2=>accepted, 3=>cancel, 4=> Completed

                if(it.data[0].bookingStatus.toString().equals("1"))
                {
                    binding.tvStatus1.text = "Trip not started."
                    binding.tvStatus1.setTextColor(resources.getColor(R.color.theme_yellow))
                    binding.ivDot1.setImageDrawable(AppCompatResources.getDrawable(this, R.drawable.icon_tracking_dot1))
                     binding.vw1.setBackgroundColor(Color.parseColor("#eb8900"))

                }
                else if(it.data[0].bookingStatus.toString().equals("2"))
                {
                    binding.tvStatus1.setTextColor(resources.getColor(R.color.theme_yellow))
                    binding.tvStatus2.setTextColor(resources.getColor(R.color.theme_yellow))
                    binding.ivDot1.setImageDrawable(AppCompatResources.getDrawable(this, R.drawable.icon_tracking_dot1))
                    binding.ivDot2.setImageDrawable(AppCompatResources.getDrawable(this, R.drawable.icon_tracking_dot1))
                    binding.vw1.setBackgroundColor(Color.parseColor("#eb8900"))
                    binding.vw2.setBackgroundColor(Color.parseColor("#eb8900"))
                }

                else if(it.data[0].bookingStatus.toString().equals("4"))
                {
                    binding.tvStatus1.setTextColor(resources.getColor(R.color.theme_yellow))
                    binding.tvStatus2.setTextColor(resources.getColor(R.color.theme_yellow))
                    binding.tvStatus3.setTextColor(resources.getColor(R.color.theme_yellow))
                    binding.ivDot1.setImageDrawable(AppCompatResources.getDrawable(this, R.drawable.icon_tracking_dot1))
                    binding.ivDot2.setImageDrawable(AppCompatResources.getDrawable(this, R.drawable.icon_tracking_dot1))
                    binding.ivDot3.setImageDrawable(AppCompatResources.getDrawable(this, R.drawable.icon_tracking_dot1))
                    binding.vw1.setBackgroundColor(Color.parseColor("#eb8900"))
                    binding.vw2.setBackgroundColor(Color.parseColor("#eb8900"))
                    binding.vw3.setBackgroundColor(Color.parseColor("#eb8900"))
                }







            } else {
                Log.d("Response", it.toString())
                toast(it.message!!)
            }
        }



        viewModel.loaderLiveTrackingApi(
            "Bearer " + userPref.user.apiToken,getBookingId.toString()
        )

        Log.d(TAG, "onCreate: " + getBookingId.toString())

    }
}