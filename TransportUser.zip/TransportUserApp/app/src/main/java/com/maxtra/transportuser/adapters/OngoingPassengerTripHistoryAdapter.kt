package com.maxtra.transportuser.adapters

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.maxtra.transportuser.R
import com.maxtra.transportuser.databinding.RowTriphistoryListBinding
import com.maxtra.transportuser.model.ongoingPassengerTripHistoryModel.OngoingPassengerHistoryData


class OngoingPassengerTripHistoryAdapter (val list: List<OngoingPassengerHistoryData>,
                                          private val listener: OnClick
) : RecyclerView.Adapter<OngoingPassengerTripHistoryAdapter.ViewHolder>() {


    inner  class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        var binding: RowTriphistoryListBinding = DataBindingUtil.bind(itemView)!!
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.row_triphistory_list, parent, false)
        return ViewHolder(itemView)    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        val data = list[position]

        /*holder.binding.linearItem.setOnClickListener(View.OnClickListener {
           val intent = Intent(context, BookingDetailsActivity::class.java)
          intent.putExtra("orderType", "4")
            context.startActivity(intent)
        })*/

        holder.binding.tvDate.text = data.bookingDate
        holder.binding.tvTime.text = data.bookingTime
        holder.binding.tvPartyname.text = data.partyName
        holder.binding.tvUserName.text = data.partyName
        holder.binding.tvDetail.text = data.partyName
        holder.binding.tvFrom.text = data.picupLocation
        holder.binding.tvTo.text = data.dropLocation
        holder.binding.tvVehicleNumber.text = data.vehicleNumber



        holder.binding.linearItem.setOnClickListener(View.OnClickListener {

            listener.onDetailClicked(data)

        })



    }

    override fun getItemCount(): Int {
        return list.size
    }



    interface OnClick{
        fun onDetailClicked(ongoingPassengerHistoryData: OngoingPassengerHistoryData)
    }

}