package com.maxtra.transportuser.util

object AppConstant {

    var DEVICE_ID = "device_id"
    var ISLOGIN = "is_login"
    var NOT_FIRST_TIME = "not_first_time"
    var IS_GUEST = "is_guest"
    var MOBILE_NO = "mobile_no"
    var DEVICE = "A"
    var USER_ID = "user_id"
    var NAME = "name"
    var EMAIL = "email"
    var LAT = "lat"
    var LONG = "long"
    var PROFILE_PIC = "profile_pic"
    var IS_NOTIFICATION = "is_notification"
    var tabIndex:Int = 0
}
