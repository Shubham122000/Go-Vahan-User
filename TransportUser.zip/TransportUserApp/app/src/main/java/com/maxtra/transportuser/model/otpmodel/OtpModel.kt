package com.maxtra.transportuser.model.otpmodel

data class OtpModel(
    val OTP: Int,
    val message: String,
    val status: Int
)