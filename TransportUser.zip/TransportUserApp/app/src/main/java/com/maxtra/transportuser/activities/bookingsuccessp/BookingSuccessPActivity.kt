package com.maxtra.transportuser.activities.bookingsuccessp

import android.content.ContentValues
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.databinding.DataBindingUtil
import com.maxtra.transportuser.R
import com.maxtra.transportuser.activities.passengers.bookingconfirmationstatus.BookingConfirmationStatusPActivity
import com.maxtra.transportuser.baseClasses.BaseActivity
import com.maxtra.transportuser.databinding.ActivityBookingSuccessPactivityBinding
import com.maxtra.transportuser.model.bookingloadermodel.BookingLoaderData
import com.maxtra.transportuser.model.bookingloadermodel.BookingLoaderDriver
import com.maxtra.transportuser.model.bookingloadermodel.BookingLoaderUser
import com.maxtra.transportuser.model.bookingpassengelmodel.BookingPassengerData
import com.maxtra.transportuser.model.bookingpassengelmodel.BookingPassengerDriver
import com.maxtra.transportuser.model.bookingpassengelmodel.BookingPassengerUser
import com.maxtra.transportuser.model.loaderpaymentsuccessmodel.LoaderPaymentSuccessData
import com.maxtra.transportuser.model.loaderpaymentsuccessmodel.LoaderPaymentSuccessDriver
import com.maxtra.transportuser.model.loaderpaymentsuccessmodel.LoaderPaymentSuccessUser
import com.maxtra.transportuser.model.passengerpaymentsuccessmodel.PassengerPaymentSuccessData
import com.maxtra.transportuser.model.passengerpaymentsuccessmodel.PassengerPaymentSuccessDriver
import com.maxtra.transportuser.model.passengerpaymentsuccessmodel.PassengerPaymentSuccessUser
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class BookingSuccessPActivity : BaseActivity() {
    private lateinit var binding : ActivityBookingSuccessPactivityBinding
    var modelDataList:BookingPassengerData?=null
    var modelUserList:BookingPassengerUser?=null
    var modelDriverList:BookingPassengerDriver?=null




    var modelOnlineDataList:PassengerPaymentSuccessData?=null
    var modelOnlineUserList:PassengerPaymentSuccessUser?=null
    var modelOnlineDriverList:PassengerPaymentSuccessDriver?=null



    var ppaymentMode:String?=null




    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_booking_success_pactivity)

        /*val extras = intent.extras
        if (extras != null) {
            modelDataList = (extras.getSerializable("modelDataList") as BookingPassengerData?)
            modelUserList = (extras.getSerializable("modelUserList") as BookingPassengerUser?)
            modelDriverList = (extras.getSerializable("modelDriverList") as BookingPassengerDriver?)
        }*/


        if (intent!=null){
            if(intent.getStringExtra("cash").equals("CASH")) {
                modelOnlineDataList = (intent.getStringExtra("modelDataList") as PassengerPaymentSuccessData?)
                modelOnlineUserList = (intent.getStringExtra("modelUserList") as PassengerPaymentSuccessUser?)
                modelOnlineDriverList =
                    (intent.getStringExtra("modelDriverList") as PassengerPaymentSuccessDriver?)
               // modelOnlineRideCode=intent.getStringExtra("modelRideCode").toString()
                Log.d(ContentValues.TAG, "onCreatepay:"+"Cash")
                ppaymentMode="cash"
            }else if(intent.getStringExtra("online").equals("ONLINE")) {
                modelDataList = (intent.getStringExtra("modelDataList") as BookingPassengerData?)
                modelUserList = (intent.getStringExtra("modelUserList") as BookingPassengerUser?)
                modelDriverList =
                    (intent.getStringExtra("modelDriverList") as BookingPassengerDriver?)
               // modelRideCode = (intent.getStringExtra("modelRideCode1") as String)
                Log.d(ContentValues.TAG, "onCreatepay:"+"Online")
                ppaymentMode="online"
            }
        }











        binding.btnNext.setOnClickListener(View.OnClickListener {
            startActivity(Intent(this, BookingConfirmationStatusPActivity :: class.java)
            .putExtra("modelDataList", modelDataList)
            .putExtra("modelUserList", modelUserList)
            .putExtra("modelDriverList", modelDriverList)
                .putExtra("payment_mode",ppaymentMode))

            finish()
        })
    }
}