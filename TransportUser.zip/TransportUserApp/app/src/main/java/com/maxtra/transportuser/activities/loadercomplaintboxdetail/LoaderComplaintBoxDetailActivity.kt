package com.maxtra.transportuser.activities.loadercomplaintboxdetail

import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.databinding.DataBindingUtil
import com.bumptech.glide.Glide
import com.maxtra.transportuser.R
import com.maxtra.transportuser.baseClasses.BaseActivity
import com.maxtra.transportuser.databinding.ActivityLoaderComplaintBoxDetailBinding
import com.maxtra.transportuser.model.loaderComplaintlistmodel.LoaderComplaintData
import com.maxtra.transportuser.util.toast
import dagger.hilt.android.AndroidEntryPoint


@AndroidEntryPoint
class LoaderComplaintBoxDetailActivity : BaseActivity() {
    private lateinit var binding : ActivityLoaderComplaintBoxDetailBinding
    private val viewModel : LoaderComplaintBoxDetailViewModel by viewModels()
    private var loaderComplaintData : LoaderComplaintData?= null




    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_loader_complaint_box_detail)

        binding.header.ivBack.setOnClickListener(View.OnClickListener {
            finish()
        })

        binding.header.tvHeaderText.setText("Complaint Detail")


        /*val layoutManagerTopSongs: RecyclerView.LayoutManager = LinearLayoutManager(this,
            GridLayoutManager.VERTICAL, false)
        binding.rvComplaintBox.setLayoutManager(layoutManagerTopSongs)
        val itemsTopSongs: List<String> = Arrays.asList("item", "item", "item", "item", "item", "item", "item", "item", "item", "item")
        binding.rvComplaintBox.setAdapter(ComplaintBoxAdapter(this, itemsTopSongs))

*/



        val data = intent.extras
        loaderComplaintData = data?.getParcelable<LoaderComplaintData>("vehicleDetails")

        viewModel.progressBarStatus.observe(this) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }

        viewModel.loaderComplaintListDetailResponse.observe(this) {
            if (it.status == 1) {
                // toast("booking Successful")
                toast(it.message!!)
                binding.tvCompalintNumber.text = it.data[0].comMessage
                binding.tvDate.text =  it.data[0].createdAt
                binding.tvBookingid.text =  it.data[0].bookingId
                binding.tvFrom.text = it.data[0].picupLocation
                binding.tvTo.text = it.data[0].dropLocation
                binding.tvTotalfare.text ="₹" + it.data[0].fare

                binding.tvBookingDate.text = it.data[0].bookingDate
                binding.tvBookingTime.text = it.data[0].bookingTime
                binding.tvVehicleType.text = it.data[0].vehicleNumbers
                binding.tvBodyType.text = it.data[0].bodyType
                binding.tvVehicleNumber.text = it.data[0].vehicleNumbers

                binding.tvComplaintText.text = it.data[0].comMessage
                binding.tvAdminRemarks.text = it.data[0].comMessage
                binding.tvPaymentMethod.text = it.data[0].paymentMode


                /*if(it.data[0].paymentMode.equals("1"))
                {binding.tvPaymentMethod.setText("Cash")}
                else  if(it.data[0].paymentMode.equals("2"))
                {binding.tvPaymentMethod.setText("Online")}*/

                /*if(it.data[0].adminRemarks.equals(" "))
                { binding.btnResolved.visibility = View.GONE }
                else
                {binding.btnResolved.visibility = View.VISIBLE}*/





            } else {
                toast(it.message!!)
            }
        }




        viewModel.loaderComplaintListDetailApi("Bearer " + userPref.user.apiToken,
            loaderComplaintData?.bookingId.toString()
        )





    }
}