package com.maxtra.transportuser.model.commonresponse

data class CommonResponseModel(
    val `data`: Int,
    val message: String,
    val status: Int
)