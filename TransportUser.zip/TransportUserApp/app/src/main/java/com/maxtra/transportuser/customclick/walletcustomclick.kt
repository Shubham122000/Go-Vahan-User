package com.maxtra.transportuser.customclick

interface walletcustomclick {

    fun onItemClick(id:String)


}