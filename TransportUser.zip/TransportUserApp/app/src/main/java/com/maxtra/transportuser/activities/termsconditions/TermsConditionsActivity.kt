package com.maxtra.transportuser.activities.termsconditions

import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.databinding.DataBindingUtil
import com.maxtra.transportuser.R
import com.maxtra.transportuser.activities.privacypolicy.PrivacyPolicyViewModel
import com.maxtra.transportuser.baseClasses.BaseActivity
import com.maxtra.transportuser.databinding.ActivityTermsConditionsBinding
import com.maxtra.transportuser.util.toast
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class TermsConditionsActivity : BaseActivity() {
    private lateinit var binding : ActivityTermsConditionsBinding
    private val viewModel : PrivacyPolicyViewModel by viewModels()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_terms_conditions)

        binding.header.ivBack.setOnClickListener(View.OnClickListener {
            finish()
        })

        binding.header.tvHeaderText.setText("Terms & Conditions")

        viewModel.termsAndConditions("Bearer " + userPref.user.apiToken)
        viewModel.progressBarStatus.observe(this) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }

        viewModel.privacyPolicyResponse.observe(this) {
            if (it.status == 1) {

                binding.tvTerms.text = it.data!!.description

            } else {
                toast(it.message!!)
            }
        }




    }
}