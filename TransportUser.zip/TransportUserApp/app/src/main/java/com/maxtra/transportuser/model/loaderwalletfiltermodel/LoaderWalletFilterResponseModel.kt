package com.maxtra.transportuser.model.loaderwalletfiltermodel

import com.google.gson.annotations.SerializedName
import com.maxtra.transportuser.model.loaderwalletlistmodel.LoaderWalletListData


data class LoaderWalletFilterResponseModel (

    var TotalAmount: TotalAmount,
    var `data`: List<LoaderWalletFilterData>,
    var message: String,
    var status: Int
)

data class LoaderWalletFilterData(
    var amount: String,
    var credit: String,
    var debit: String,
    var name: String,
    var transaction_date: String,
    var user_id: Int
)
data class TotalAmount(
    var TotalAmount: String,

    )