package com.maxtra.transportuser.activities.loadercompletedbookingdetails

import android.app.Dialog
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.CheckBox
import androidx.activity.viewModels
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.LinearLayoutManager
import com.maxtra.transportuser.R
import com.maxtra.transportuser.activities.loaderraisecomplaint.LoaderRaiseComplaintActivity
import com.maxtra.transportuser.activities.loadertracktruckdriver.LoaderTrackTruckDriverActivity
import com.maxtra.transportuser.adapters.LoaderCancelTripReasonAdapter
import com.maxtra.transportuser.baseClasses.BaseActivity
import com.maxtra.transportuser.databinding.ActivityLoaderCompletedBookingDetailsBinding
import com.maxtra.transportuser.databinding.BottomSheetCancelTripBinding
import com.maxtra.transportuser.databinding.BottomSheetRidecancellationBinding
import com.maxtra.transportuser.model.completedloadertriphistorymodel.CompletedLoaderHistoryData
import com.maxtra.transportuser.model.loadercancelreasonmodel.LoaderCancelReasonData
import com.maxtra.transportuser.util.toast
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class LoaderCompletedBookingDetailsActivity : BaseActivity() {

    private lateinit var binding : ActivityLoaderCompletedBookingDetailsBinding
    private var selectedLoaderCompletedHistoryData: CompletedLoaderHistoryData? = null
    private val viewModel: LoaderCompletedBookingDetailsViewModel by viewModels()



    private var listData: ArrayList<LoaderCancelReasonData> = ArrayList()
    private var loaderCancelReasonAdapter: LoaderCancelTripReasonAdapter? = null
    var crnNumber = ""
    private var listReasonType_id:ArrayList<String> = ArrayList()
    var reasontypevalue_id: String? = ""
    private lateinit var str: String


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
      //  setContentView(R.layout.activity_loader_completed_booking_details)

        binding = DataBindingUtil.setContentView(this, R.layout.activity_loader_completed_booking_details)

        binding.header.ivBack.setOnClickListener(View.OnClickListener {
            finish()
        })

        binding.header.tvHeaderText.setText("Booking Details")


        val data = intent.extras
        selectedLoaderCompletedHistoryData = data?.getParcelable<CompletedLoaderHistoryData>("loaderCompletedHistoryDetails")

       Log.d("TAG___", "onCreate: " + selectedLoaderCompletedHistoryData!!.bookingId.toString())

        viewModel.progressBarStatus.observe(this) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }

        viewModel.loaderCompletedHistoryDetailResponse.observe(this) {
            if (it.status == 1) {
                // toast("booking Successful")
                toast(it.message)


                binding.tvBookingId.text = it.data[0].booking_id
                binding.tvTripStatus.text = it.data[0].booking_status
                binding.tvPaid.text = it.data[0].fare



                binding.tvBookingId.text = it.data[0].booking_id
                binding.tvTripStatus.text = it.data[0].booking_status
                binding.tvDate.text = it.data[0].booking_date
                binding.tvTime.text = it.data[0].booking_time
                binding.tvPickup.text = it.data[0].picup_location
                binding.tvDropoff.text = it.data[0].drop_location
                binding.tvVehicleType.text = it.data[0].vehicle_name
                binding.tvBodyType.text = it.data[0].body_type
                binding.tvVehicleNumber.text = it.data[0].vehicle_numbers
                binding.tvTotalLoads.text = it.data[0].booking_time
                binding.tvPartyName.text = it.data[0].booking_time


                if (it.data[0].payment_mode.equals("1")) {
                    binding.tvPaymentMethod.setText("Cash")
                } else if (it.data[0].payment_mode.equals("2")) {
                    binding.tvPaymentMethod.setText("Online")
                }

                binding.tvUseremail.text = it.userDetails.email
                binding.tvUsername.text = it.userDetails.name
                binding.tvUserphone.text = it.userDetails.mobile_number


            /*    if(it.data[0].payment_mode.equals("1"))
                {binding.tvPaymentMethod.setText("Cash")}
                else  if(it.data[0].payment_mode.equals("2"))
                {binding.tvPaymentMethod.setText("Online")}*/




//                binding.tvDate.text = it.data[0].booking_date
//                binding.tvTime.text = it.data[0].bookingTime
//                binding.tvPickup.text = it.data[0].picupLocation
//                binding.tvDropoff.text = it.data[0].dropLocation
//                binding.tvVehicleType.text = it.data[0].vehicleName
//                binding.tvBodyType.text = it.data[0].bodyType
//                binding.tvVehicleNumber.text = it.data[0].vehicleNumber
//                binding.tvTotalLoads.text = it.data[0].vehicleNumber
//                binding.tvPartyName.text = it.data[0].vehicleNumber
//                binding.tvPartyNumber.text = it.data[0].vehicleNumber
//
//
//
//                binding.tvDriverName.text = it.ownerDetails?.name
//                binding.tvDriverPhone.text = it.ownerDetails?.mobile
//                // binding.tvRidesNumber.text = it.data[0].r
//                binding.tvUsername.text = it.userDetails!!.name
//                binding.tvUserphone.text = it.userDetails!!.mobileNumber
//                binding.tvUseremail.text = it.userDetails!!.email
//
//
//



                //  userPref.setDriverId(it.data[0]!!.driverId.toString())

            } else {
                toast(it.message!!)
            }
        }




        viewModel.loaderOngoingHistoryDetailApi(
            "Bearer " + userPref.user.apiToken,
            selectedLoaderCompletedHistoryData?.bookingId!!
        )


        viewModel.getLoaderCancelReasonListApi("Bearer " + userPref.user.apiToken)




        binding.btnRaiseComplaint.setOnClickListener(View.OnClickListener {

            val intent = Intent(this, LoaderRaiseComplaintActivity::class.java)
            intent.putExtra("BookingId", selectedLoaderCompletedHistoryData?.bookingId!!.toString())
            startActivity(intent)


        })

       /* binding.btnCanceltrip.setOnClickListener(View.OnClickListener {
            cancelReasonDialog()
        })
        binding.btnTracktruck.setOnClickListener(View.OnClickListener {
            val intent = Intent(this, LoaderTrackTruckDriverActivity::class.java)
            intent.putExtra("BookingId", selectedLoaderCompletedHistoryData?.bookingId!!.toString())
            startActivity(intent)
        })*/


    }



    private fun cancelReasonDialog() {
        val cDialog = Dialog(this, R.style.Theme_Tasker_Dialog)
        val bindingDialog: BottomSheetCancelTripBinding = DataBindingUtil.inflate(
            LayoutInflater.from(this),
            R.layout.bottom_sheet_cancel_trip,
            null,
            false
        )
        cDialog.setContentView(bindingDialog.root)

        cDialog.setCancelable(false)
        cDialog.window!!.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        cDialog.show()

        viewModel.loaderCancelReasonResponse.observe(this) {
            if (it.status == 1) {
                toast(it.message!!)
                listData.clear()
                listData.addAll(it.data)
                loaderCancelReasonAdapter =
                    LoaderCancelTripReasonAdapter(this, listData)
                bindingDialog.rvReasons.apply {
                    adapter = loaderCancelReasonAdapter
                    layoutManager = LinearLayoutManager(context)

                }
            } else {
                Log.d("Response", it.toString())
                toast(it.message!!)
            }
        }








        viewModel.loaderTripCancelResponse.observe(this) {
            if (it.status == 1) {
                toast(it.message!!)
                crnNumber = it.CRN.toString()
                cDialog.dismiss()
                rideCancelledDialog()

                //   finish()
            } else {
                Log.d("Response", it.toString())
                toast(it.message!!)
            }
        }


        bindingDialog.btnConfirmCancel.setOnClickListener {
            // cDialog.dismiss()

            listReasonType_id.clear()
            bindingDialog.etFeedback.text.toString()
            for (i in 0 until bindingDialog.rvReasons.childCount){
                val cbReason =bindingDialog.rvReasons.getChildAt(i).findViewById(R.id.cb_reason) as CheckBox
                if (cbReason.isChecked){
                    val id=listData[i].id
                    listReasonType_id.add(id.toString())

                    reasontypevalue_id =  listReasonType_id.toString()
                    str= android.text.TextUtils.join(",", listReasonType_id)
                    //   datetypevalue_id = android.text.TextUtils.join(",", listDateType_id);

                }
            }


            viewModel.loaderTripCancelApi(
                "Bearer " + userPref.user.apiToken,
                selectedLoaderCompletedHistoryData?.bookingId!!.toString(),
                str,
                bindingDialog.etFeedback.text.toString()
            )
            Log.d("CheckBoxInfo",   selectedLoaderCompletedHistoryData?.bookingId!!.toString()+str+bindingDialog.etFeedback.text.toString())

        }
        bindingDialog.ivClose.setOnClickListener {
            cDialog.dismiss()
        }

    }



    private fun rideCancelledDialog() {
        val cDialog = Dialog(this, R.style.Theme_Tasker_Dialog)
        val bindingDialog: BottomSheetRidecancellationBinding = DataBindingUtil.inflate(
            LayoutInflater.from(this),
            R.layout.bottom_sheet_ridecancellation,
            null,
            false
        )
        cDialog.setContentView(bindingDialog.root)

        cDialog.setCancelable(false)
        cDialog.window!!.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        cDialog.show()

        bindingDialog.tvCRN.setText("Your booking with "+  crnNumber +" has been cancelled successfully.")
        cDialog.dismiss()
        this.finish()

        bindingDialog.ivClose.setOnClickListener {
            cDialog.dismiss()
        }
        bindingDialog.btnOk.setOnClickListener {
            cDialog.dismiss()
        }

    }

}