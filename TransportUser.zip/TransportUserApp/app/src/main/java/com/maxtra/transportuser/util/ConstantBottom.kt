package com.maxtra.transportuser.util

class ConstantBottom {


    object DeliveryDashboardBottomNavTab {
        const val HOME = 100
        const val MOVIES = 101
        const val TV = 102
        const val LIST = 103
        const val MORE = 104
    }
}